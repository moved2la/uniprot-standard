# Handoff — Step 4b: Muscle bound-metabolite adjustment (carnosine → histidine)

**Project:** Sequence-Derived Amino Acid Standard for the Reference Adult Human
**Plan:** `docs/00_project_plan_R8.md` (Step 4b, D68)
**Governing rule:** `PROVENANCE.md`
**Depends on:** Step 4 (`outputs/standard/_calculated_amino_acid_standard.tsv`, `config/fiber_type_mix.ini`, the amino acid masses fetched in the composition step)
**Feeds:** Step 6 (Match Rate reference "skeletal muscle + bound pools"), Step 8 (whole-body composite)
**Status:** COMPLETE 2026-09-17 (delivery 9 = close-out). Decisions D72–D81; report in `docs/step4b_report.md`; plan R9 issued; Step 6 handoff drafted.

---

## Goal

Add the histidine the muscle holds as carnosine (β-alanyl-L-histidine) to the skeletal muscle
standard, as a stated, cited, separately-reported adjustment. The protein-only standard is not
changed; the adjusted standard is a new table beside it.

## The sources — where each one is and where it lands

Source ids are the `[source.*]` keys in `config/mass_fraction_decisions.ini`. Files land under
`data/literature/<source_id>/` with the URL's basename as the file name (rule F7) plus, when the URL has no extension, the one the bytes imply (F7b: a PDF is always `.pdf`). "code" = `fetch_literature`
downloads it; "you" = obtain it in a browser, save under the stored name, set `file.1.obtained = manual`.
If a "code" row comes back flagged as HTML, it becomes a "you" row (the flag says so).

| source_id | Article page | File URL (what the fetcher requests) | Stored as | Who |
|---|---|---|---|---|
| `harris_1998` | https://www.tandfonline.com/doi/abs/10.1080/026404198366443 | the abstract page itself (article paywalled) | `data/literature/harris_1998/026404198366443.pdf` (the abstract page printed to PDF) | **you** |
| `tallon_2007` | https://link.springer.com/article/10.1007/s10522-006-9038-6 | — (gated; abstract lacks the values; citation only, no file) | — | — |
| `harris_2012` | https://link.springer.com/article/10.1007/s00726-012-1233-y (open; also PMC3374101) | https://link.springer.com/content/pdf/10.1007/s00726-012-1233-y.pdf | `data/literature/harris_2012/s00726-012-1233-y.pdf` | code |
| `vega_2022` | https://link.springer.com/article/10.1007/s00256-022-04149-8 (PubMed 35978163) | — (dropped 2026-09-17; citation only, no file) | — | — |
| `baguet_2009` | https://journals.physiology.org/doi/full/10.1152/japplphysiol.91357.2008 (PubMed 19131472) | https://journals.physiology.org/doi/pdf/10.1152/japplphysiol.91357.2008 (free on the site; the journal 403s scripts) | `data/literature/baguet_2009/japplphysiol.91357.2008.pdf` | **you** |
| `yamaguchi_2021` | https://journals.lww.com/acsm-msse/Fulltext/2021/05000/Kinetics_of_Muscle_Carnosine_Decay_after___Alanine.22.aspx (PubMed 33148972) | https://irep.ntu.ac.uk/id/eprint/41679/1/1389887_Sale.pdf (accepted manuscript) | `data/literature/yamaguchi_2021/1389887_Sale.pdf` | code |
| `icrp_2002` | https://www.icrp.org/publication.asp?id=ICRP%20Publication%2089 | https://psec.uchicago.edu/Simulation/icrpp89.pdf (public mirror) | `data/literature/icrp_2002/icrpp89.pdf` | code (fetched; Layer C document; not the D77 source) |
| `mingrone_2001` | https://journals.physiology.org/doi/full/10.1152/ajpendo.2001.280.2.E365 | https://journals.physiology.org/doi/pdf/10.1152/ajpendo.2001.280.2.E365 (free on the site; the journal 403s scripts) — **the D77 source** | `data/literature/mingrone_2001/ajpendo.2001.280.2.E365.pdf` | **you** |
| `smith_2011` | https://pmc.ncbi.nlm.nih.gov/articles/PMC3043790 | — (no file until its citation is completed from the article) | — | — |

Author lists still to be read from the article on disk before the `retrieved` date goes in the config:
Harris 1998, Tallon 2007, Vega 2022 (complete the list), Yamaguchi 2021, Mingrone 2001, and the whole
citation of the FSR review (`smith_2011` — its id is a guess at the first author and is renamed once read).

## What the sources say (found 2026-09-16; author lists verified by fetching unless marked)

**Pool size — single fibers, human vastus lateralis (per kg dry muscle)**
- Harris, Dunnett & Greenhaff 1998, J Sports Sci 16:639–643, DOI 10.1080/026404198366443. Four men.
  Type I 10.5 ± 7.6, type II 23.2 ± 17.8 mmol/kg dm. **Gated (Taylor & Francis); author list read
  from citing papers' reference lists, not yet from the article — verify when the file is obtained (F5).**
- Tallon et al. 2007, Biogerontology, DOI 10.1007/s10522-006-9038-6. Nine young (20–35 y) and nine
  elderly subjects, pooled single fibers by ATPase type. Second per-fiber-type source; young-group
  values to be read from the article. **Author list not yet verified.**

**Pool size — whole muscle, in vivo MRS (per kg wet muscle)**
- Vega, Ricaurte, Estrada-Castrillón, Reyngoudt, … 2022, Skeletal Radiology, DOI 10.1007/s00256-022-04149-8.
  Vastus lateralis 5.4 ± 1.5 mmol/kg ww (n = 30); men 6.2 ± 1.3 (n = 15), women 4.6 ± 1.2 (n = 15).
  **Full author list to be read from the article.**

**Which dipeptides exist in human muscle**
- Harris, Wise, Price, Kim, Kim & Sale 2012, Amino Acids 43:5–12, DOI 10.1007/s00726-012-1233-y
  (open access, PMC3374101; authors verified on the Springer page and the NTU repository record).
  States that in human (and equine) muscle carnosine is the sole histidine-containing dipeptide;
  type I : II ratio in human vastus lateralis 1.3–2; washout t½ 5–9 weeks. → anserine is not carried.

**Turnover (washout after β-alanine loading; first-order fit)**
- Baguet, Reyngoudt, Pottier, Everaert, Callens, Achten & Derave 2009, J Appl Physiol 106:837–842,
  DOI 10.1152/japplphysiol.91357.2008 (authors verified on the journal page). 30 % of the loaded
  increase gone at 3 wk → t½ 5.8 wk (their Discussion); linear washout 2.5–3.5 %/wk.
- Yamaguchi et al. 2021, Med Sci Sports Exerc 53:1079, DOI 10.1249/MSS.0000000000002559
  (accepted manuscript open on the NTU IRep and USP repositories). Exponential model t½ 4.6 wk
  (95 % CI 3.2–7.0); linear model fits equally well over 16 wk. Cites Harris et al. 2009 t½ 8.6 wk
  (a meeting abstract — secondary; carried only as the upper end of the range if at all).
  **Author list to be read from the manuscript.**

**Muscle protein content (the denominator) — source still to be settled**
- ICRP Publication 89 (Annals of the ICRP 32(3–4), 2002) §13.2 "Gross composition of body tissues" —
  public PDF mirror found; the section has not yet been read. First in-thread task: fetch by code,
  read §13.2, confirm it gives water and protein for skeletal muscle. This is the Layer C document.
- Fallback: Am J Physiol Endocrinol Metab 280:E365, 2001 ("Unreliable use of standard muscle
  hydration value in obesity"): water 76.3 ± 3.2 %, protein 15.5 ± 3.7 % of wet mass, 16
  normal-weight subjects, direct chemical analysis. Authors not yet verified.
- Woodard & White 1986, Br J Radiol 59:1209 ("The composition of body tissues") — the reassessment
  of ICRP 23 that dosimetry uses; gated. Third option.

**Muscle protein turnover (turnover-frame sensitivity only)**
- Review, J Appl Physiol 2011 (PMC3043790, "Human muscle protein turnover — why is it so variable?"):
  basal mixed-muscle FSR in the vastus lateralis of healthy young adults ranges ~0.020–0.030 %/h
  (low) to ~0.080–0.095 %/h (high) across labs. **Authors to be verified.** This four-fold spread is
  why the turnover frame is a sensitivity, not the standard.

## Decisions agreed 2026-09-16 (logged as D73–D77 in `docs/decisions.md`)

*Numbering note:* `decisions.md` ended at D66; plan R7/R8's D67–D71 had not been logged and `fiber_type_mix.ini` carried a placeholder "D67". Delivery 1 appends D67–D71 from the plan, logs the fiber-type mix as **D72**, and takes **D73–D77** for this step; `fiber_type_mix.ini` now says D72 and `bound_metabolite_pools.ini [meta] decisions` carries the D-numbers so a renumbering is one config edit.

- **D73 Frame.** The adjustment in the standard is the *pool-size* (inventory) frame: histidine held
  as carnosine is added to histidine held as protein, per kg of the same muscle. The
  turnover-weighted (resupply) frame is reported as a sensitivity only — it depends on two rates
  whose cited ranges give a spread, not a number. Rationale: the standard is "what the body is made
  of"; rates of resupply belong with Match Rate Plus.
- **D74 Basis.** Per-fiber-type single-fiber values fill the fiber type I / IIa / IIx columns; the
  single-fiber sources measure "type II", so IIa and IIx receive the same value and the header says
  so. The whole-muscle MRS value is the cross-check, reported beside it as a second measurement
  option, no verdict (the D54 pattern).
- **D75 Pools carried.** Carnosine only. Anserine is not carried: the cited review states carnosine
  is the sole histidine-containing dipeptide in human muscle. Creatine and glutathione stay out of
  scope for this step (non-EAA; D68 leaves them for a later extension).
- **D76 Deliverable shape.** `_calculated_amino_acid_standard.tsv` is untouched. The adjusted
  standard is a separate table with the same ten columns; a per-amino-acid difference table sits
  beside it. No column of the protein-only table changes.
- **D77 Protein-content source — settled 2026-09-17: Mingrone et al. 2001**, the direct chemical measurement (wet
  basis; rectus abdominis, stated). ICRP 89 chapter 13 was read and gives elemental composition only; a protein value
  computed from its nitrogen was offered and declined — every literature number here is a harvested measurement.
- **D74 amended 2026-09-17:** no whole-muscle cross-check. Vega 2022 dropped (gated); Tallon 2007 citation-only. The basis
  and subgroup sensitivities are not computed; the per-fiber-type columns rest on Harris 1998's abstract alone, stated.
- **D78 Green light.** `bound_pools` stops before computing if any `source_id` in the config has no hashed file in the
  manifest (delivery 2). The general form is 7b's.

## The calculation (to be written out in `docs/formula.md` as well)

Per fiber type *ft*, per kg of muscle on the source's basis (dry for single-fiber values):

1. Total free-amino-acid mass of the protein, per kg: `A_ft = P × r`, where `P` is the cited
   protein mass per kg and `r` is the pipeline's own free-mass : residue-mass ratio for that
   profile (already computed in the composition and aggregation stages — the "115" factor).
2. Histidine in protein, per kg: `H_prot_ft = A_ft × s_His,ft`, where `s_His,ft` is histidine's
   share of the protein-only `total` column (free convention).
3. Histidine in carnosine, per kg: `H_carn_ft = c_ft × M_His / 1000`, where `c_ft` is the cited
   carnosine content (mmol/kg) and `M_His` is the free histidine mass already fetched from PubChem
   (one mole of carnosine yields one mole of histidine; the β-alanine is not one of the twenty and
   is not counted).
4. Adjusted profile: histidine's mass becomes `H_prot_ft + H_carn_ft`, the other nineteen are
   unchanged, and all twenty are renormalised to 100 %. Contractile and builders columns are
   protein-only by definition and are copied unchanged; the adjustment applies to `total` and, via
   the fiber-type mix, to `standard`.
5. Difference table: adjusted minus protein-only, per amino acid, per column.

If `P` is only available on the wet basis while `c_ft` is on the dry basis (or vice versa), the
cited water content converts one to the other; the conversion is one line in the config with its
own citation and is shown in the output header.

## Sensitivities (each its own file; magnitudes from config, never defaulted by code)

- **Turnover frame.** `H_carn × k_carn` against `H_prot × k_prot` over the grid
  k_carn ∈ {t½ 4.6, 5.8, 8.6 wk} × k_prot ∈ {FSR low, FSR high}; the resulting His share and its
  spread, labelled as the resupply frame.
- **Basis.** The whole-muscle MRS value applied uniformly vs the per-fiber-type values; the
  per-amino-acid difference in `standard`.
- **Sex.** The men's and women's whole-muscle values through the same calculation; His shift.
- **Published spread.** The single-fiber SDs (large: ±72 % and ±77 %) carried through as
  low/high, in the same log-space treatment the weights use.

## Outputs (all in `outputs/standard/`)

- `_calculated_amino_acid_standard_with_bound_pools.tsv` — ten columns, free convention, sums to 100.
- `bound_pool_adjustment_per_amino_acid.tsv` — adjusted minus protein-only.
- `bound_pool_amounts_per_kg_muscle.tsv` — per fiber type: pool, protein-bound amount, ratio, in g per kg on the pool's basis.
- `sensitivity_bound_pool_turnover_frame.tsv`, `sensitivity_bound_pool_basis.tsv`,
  `sensitivity_bound_pool_sex.tsv`, `sensitivity_bound_pool_spread.tsv`.
- Headers carry: input file hashes, the config's source rows, the subject-population lines (four
  men, single fibers; n = 30 mixed-sex MRS), and the version label
  `ref = skeletal muscle protein + carnosine (D73, D74, D75, D76, D77)` (the label and the D-numbers come from `[meta]` in the config).

## Delivery numbering

Every tarball is an increment: delivery 1 (stage, config skeleton, docs), 2 (D74/D77/D78: Vega dropped, Mingrone, the
green light), 3 (fetcher: unchanged-on-disk, locked file is a flag), 4 (fetcher: F7b extensions), 5 (fetcher: F4b, a
failed re-fetch of a verified pinned file is not a flag). The two same-day fetcher patches were mislabelled as parts of
delivery 2 when shipped; they are 3 and 4. Delivery 6 = the filled config; 7 = page-level locations; 8 = the retrieval-time staleness fix; 9 = close-out.

## Delivery 9 (2026-09-17) — close-out

`eaa_subset_with_bound_pools.tsv` added to the stage (the nine FAO 2013 headings as their share of the profile,
protein-only beside with-pools, per total column and the standard); methods §Bound metabolite pools filled from the
run of 02:12Z; `docs/step4b_report.md`; `docs/00_project_plan_R9.md`; `docs/handoffs/06_match_rate_handoff.md`;
pipeline map and excerpt spec updated. Run `python run.py standard` once more to write the new EAA table (the
currency test will ask for it); everything else is documents.

## Delivery 8 (2026-09-17) — the staleness trap

`test_mass_fraction_outputs_are_current` failed after the 4b fetch: every fetch stamped every manifest entry's
`retrieved` with "now" (verified-unchanged files included), and the four generated weight files copied that stamp into
their headers, so they read as stale with nothing changed (D81). Fix: those files no longer carry the retrieval time
(they point at the manifest; the hash identifies the file), and the fetcher keeps a file's first retrieval time when
its hash is already in the manifest (F2b). After extracting: `python run.py mass-fractions --offline` once, then
`python run.py standard`; from then on a fetch cannot invalidate the weights. The 7b item stands: the source list
leaves `mass_fraction_decisions.ini`, and each stage hashes only the config sections it reads.

## Delivery 7 (2026-09-17) — locations as page + table/column/paragraph

Every `location` in `bound_metabolite_pools.ini` is now a page number plus the table row and column, or the column and
paragraph, so a person opens the PDF and lands on it (e.g. `p. E368, Table 1, row "Proteins, %", column "Control Group
(n = 16)"`); the study notes moved to a `note` key and the file path to a `file` key beside each value. One page to
check in the PDF on disk: Harris 2012's "Species" section is given as p. 6 from the article's layout (the open HTML
carries no page numbers).

## Delivery 6 (2026-09-17) — the config, filled

`config/bound_metabolite_pools.ini` is filled (D79: values read by Claude from the PDFs on disk, each with its
location; audited by the author). What is in it:

| Section | Value | Where it was read |
|---|---|---|
| `carnosine.single_fiber.type_I` | 10.5 ± 7.6 mmol/kg dry | Harris 1998, Abstract (four men; ± kind not stated) |
| `carnosine.single_fiber.type_II` | 23.2 ± 17.8 mmol/kg dry → fiber types IIa and IIx | Harris 1998, Abstract |
| `protein_content` | 155 ± 37 g/kg wet (15.5 ± 3.7 %) | Mingrone 2001, Table 1, control group n = 16, p. E368 |
| `water_content` | 763 ± 32 g/kg wet (76.3 ± 3.2 %) | Mingrone 2001, Table 1 (abstract prints 3.3) |
| `pool.carnosine` sole-pool statement | "carnosine is the sole M-HCD" in human muscle | Harris 2012, section Species, first paragraph |
| `turnover.carnosine.yamaguchi_2021` | t½ 4.6 wk (95 % CI 3.2–7.0) | manuscript lines 332–334 |
| `turnover.carnosine.baguet_2009` | t½ 5.8 wk (authors' first-order figure; observed washout linear) | Discussion, p. 841 |
| `turnover.muscle_protein.*` | **removed** — no FSR source on disk (author's call); the resupply sensitivity is NOT computed | — |

Author lists corrected from the PDFs: Mingrone 2001 has eight authors (Mingrone, Bertuzzi, Capristo, Greco, Manco,
Pietrobelli, Salinari, Heymsfield); Harris 1998 and Yamaguchi 2021 confirmed. `smith_2011` marked not pursued. D79 and
D80 (fetch rule retired, pinned for 7b) logged. Header citation lines shortened to source id + location.

Protein on the pool's dry basis: 155 / (1 − 0.763) = 654 g/kg dry. Run `python run.py standard`; expect the adjusted
table, the difference table, the per-kg table, the spread sensitivity; three sensitivities reported NOT computed.

## Delivery 5 (2026-09-17)

`fetch_literature` rule F4b: when a re-fetch fails (the contaminants list returned a 504 from Zenodo on the third
fetch) but the file is already on disk and hashes to its pin, it is logged `[OK] … verified on disk; re-fetch failed`
and the manifest entry is kept; only a failure with no verified file on disk is a flag. Fetch log of
2026-09-17T01:28Z: every 4b source hashed (Harris 1998, Baguet 2009, Mingrone 2001 hand-obtained; Harris 2012,
Yamaguchi 2021, ICRP 89 fetched); Tallon 2007 has no file by decision.

## Delivery 2 (shipped 2026-09-17; patched the same day — see Delivery numbering)

*Patch 2 (F7b):* a stored file always carries an extension — when the URL basename has none, the fetcher appends the one
the bytes imply (`%PDF` → `.pdf`); hand-obtained files are found with or without it. A file a person cannot open is not a
record ("I have to be able to read the files as a human").

*Patch:* `fetch_literature` no longer rewrites a file whose bytes already match its pin (`[OK] … unchanged on disk`), and
a file it cannot write — locked by a PDF viewer or a sync client — is a `[FLAG]` with the reason, not a crash (F3/F4;
surfaced when `icrpp89.pdf` was open in a viewer during the second fetch).

Config: `bound_metabolite_pools.ini` loses its whole-muscle sections and points `[protein_content]` / `[water_content]`
at `mingrone_2001` (wet basis; the paper reports percent of wet tissue — value = percent × 10). Sources:
`vega_2022` → `not_used`, no file; `mingrone_2001` → file entry, `obtained = manual`; `icrp_2002` → role
`reference_body_document` (D67), note says why it is not D77. Code: the green light (D78) in `bound_pools` — every
`source_id` named must have a hashed file in `manifest.ini`, else `[STOP]`; three tests. Docs: D74, D77, D78 in
`decisions.md`; methods, conventions, pipeline map updated. Twelve synthetic tests pass.

Files you place before the fetch: `harris_1998/026404198366443.pdf` (abstract page as PDF), `baguet_2009/japplphysiol.91357.2008.pdf`
and `mingrone_2001/ajpendo.2001.280.2.E365.pdf` (PDFs from the journal site). Then
`python run.py mass-fractions --stop-after fetch_literature` → flags: 0 expected → `python run.py standard` → transcribe → run again.

## Delivery 1 (shipped 2026-09-16; run it, then transcribe)

New: `pipeline/bound_pools.py` (stage 1b of `python run.py standard`, after `aggregate`), `config/bound_metabolite_pools.ini`
(skeleton, every value `___`), `tests/test_bound_pools.py` (nine synthetic tests). Edited: `run.py`, `pipeline/common.py`,
`pipeline/excerpt.py` (the new tables in the excerpt spec), `tests/test_standard_outputs_current.py` (currency, column sums,
copied columns, the placeholder test), `config/mass_fraction_decisions.ini` (sources P1–P9), `config/fiber_type_mix.ini`
(decision D72), `docs/conventions.md` (hand-written file row; rule A10), `docs/pipeline_map.md`, `docs/formula.md`
(steps 9–12 and a worked line), `docs/methods.md` (§Bound metabolite pools with placeholders), `docs/decisions.md`
(D67–D77), `README.md`.

Run order on the workstation:
1. Save the Harris 1998 abstract page as a PDF named `026404198366443.pdf` (the URL basename, rule F7, plus `.pdf`, F7b) in
   `data/literature/harris_1998/`. The article is paywalled; every value used is in the abstract, and the config says so.
2. `python run.py mass-fractions --stop-after fetch_literature` — the literature stage only. It pulls the open sources
   (Harris 2012, Tallon 2007, Vega 2022, Baguet 2009, Yamaguchi 2021, ICRP 89 mirror, Mingrone 2001) and hashes the
   hand-obtained one; a publisher that serves HTML is flagged with the instruction to download by hand and set
   `obtained = manual`. A gated source is a manual step whatever the rule says; where only its abstract is free and the
   abstract carries the values, the abstract page is the file (as for Harris 1998) and the config's published_name says so.
3. `python run.py standard` — `bound_pools` runs with the config still `___`: it writes `bound_pools_summary.ini` saying
   what is not filled and no adjusted table; `test_bound_metabolite_pools_is_filled_in` fails, as intended. Upload
   `excerpts/` after `python run.py excerpt` so the real `amino_acid_g_per_100g_protein_free.tsv` is on record here.
4. Read ICRP 89 chapter 13 from the fetched file; settle D77; transcribe the config (every author list checked against the
   article on disk); `python run.py standard` again; upload the excerpts. Then the numbers get discussed.

## Code

- New stage `bound_pools` in `python run.py standard`, run after `aggregate` (reads the
  protein-only standard, the config, and the amino acid masses; writes the files above).
  `uncertainty`, `stress`, and `plots` are unchanged and still describe the protein-only standard.
- `fetch_literature` gains the open-access sources (Harris 2012, Yamaguchi 2021 manuscript,
  Baguet 2009 if the journal serves the PDF, ICRP 89 mirror); the gated ones (Harris 1998,
  Tallon 2007 if used, Woodard & White 1986 if used) are hand-obtained under F5 and SHA-256 pinned.
- `config/bound_metabolite_pools.ini` — author-transcribed values (D50 pattern), skeleton delivered
  with this handoff, all values `___` until transcribed. Sits flat in `config/`; the per-category
  layout waits for Step 7b.
- `docs/pipeline_map.md`, `docs/methods.md` §"Bound metabolite pools", `docs/formula.md`,
  `docs/decisions.md` D67–D77, tests.

## Explicitly out of scope

Creatine, glutathione, and any non-His pool; the free amino acid pool (excluded by D68); any change
to the protein set, the weights, or the protein-only standard; other tissues.

## Deferred / raised

- **For the Step 7b refactor (raised 2026-09-16 from the first fetch log):** (a) the literature fetch becomes its own
  command (`python run.py fetch-literature`), and `mass-fractions` runs calculations only — a fetch inside a calculation
  command "doesn't make logical sense"; (b) a green light before any calculation: no offline command runs while a cited
  source has no hashed file in `data/literature/manifest.ini`. Today the gate exists only inside one command (flags stop
  that command); `standard` runs offline and never checks the manifest. Delivery 2 adds the manifest check to `bound_pools`
  for this step; the general gate is 7b's.
- First fetch (2026-09-17T00:32Z): 3 of 7 open attempts landed (Harris 2012, Yamaguchi 2021, ICRP 89 mirror); Springer
  served HTML for Tallon 2007 and Vega 2022 (gated); the physiology journals return 403 to scripts (Baguet 2009, Mingrone
  2001). Resolution in the source table above.

- Whether a mixed-sex single-fiber source exists (the per-fiber-type data found are male-only;
  the fiber-type mix is female-only) — noted for the paper's limitations.
- Carnosine correlates with type II fiber area (PLoS ONE 2011, PMC3131401) — a possible paper-step
  cross-check between the fiber-type mix and whole-muscle carnosine; not used here.
- Vegetarian muscle carnosine is roughly half the omnivore value (Harris 2012) — a population
  sensitivity for Step 6 if Match Rate is ever reported for a vegetarian reference.

## Handoff to Step 6

Written as `docs/handoffs/06_match_rate_handoff.md`. In one line: two muscle references exist with version labels
(`skeletal muscle protein`; `skeletal muscle protein + carnosine`), both in the free convention summing to 100, with
the FAO 2013 indispensable subset for each; Step 6 transcribes the spreadsheet's formula, decides EAA-only vs all
twenty, the cysteine treatment, and the surplus rule, ingests USDA in the free convention, and publishes
version-labelled scores plus the Gorissen comparison document.
