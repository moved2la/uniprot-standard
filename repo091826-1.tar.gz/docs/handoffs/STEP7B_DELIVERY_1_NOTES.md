# Step 7b — Delivery 1: `file.<n>.name` (F7 amended)

**What changed and why.** `fetch-literature` looked for a stored file under the last segment of its
URL (F7). ACS supplement links end in `/`, so the segment is empty and the stage looked for a file
called `download` — the two `bryk_2017` flags in the 20:35 run. The rule is now the one the author
set: the stored file keeps the name it was downloaded with, recorded in config as `file.<n>.name`;
the URL is provenance only. Sections without `file.<n>.name` keep the URL rule unchanged, so no
existing source moves.

**Files in this delivery (only these).**
- `pipeline/fetch_literature.py` — `file_entries()` yields `name`; `build()` looks for `name or
  filename_from_url(url)`; a trailing-slash URL with no name gets a flag that says what to add; a
  `___` name is a flag; the manifest records `name_from = config | url`. Docstring F7 amended.
- `tests/test_fetch_literature.py` — three tests: a config-named file is found whatever the URL says;
  a trailing-slash URL without a name flags with the fix in the message; existing sources keep the
  URL rule and the manifest says so. 16 synthetic tests pass (13 before + 3).
- `docs/conventions.md` — the F7 row.

**Not in this delivery.** `config/literature_sources.ini` — yours. To clear the 20:35 flags:
`[categories] columns` gains `blood`; `bryk_2017` gets `file.1.name = pr7b00025_si_002.xlsx` and a
`file.2` that matches what is on disk (the URL on that line names the SI PDF, the hash is the
article PDF's); `anderson_2002 file.1.sha256` blanked so the run records the copy on disk.

**Decision to log.** The F7 amendment needs its D-number in `docs/decisions.md`; the text is
drafted with the D95–D102 batch, next.

**Rerun.** `python run.py fetch-literature`. Re-hashing unchanged files moves nothing (D92).
