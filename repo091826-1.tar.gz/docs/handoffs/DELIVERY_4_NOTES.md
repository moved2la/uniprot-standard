# Step 6 — delivery 4: the output layout

**Date:** 2026-09-17 · **Decisions:** none new (D86–D88 stand) · **Contents:** 11 files, all changes to delivery 3.

## 1. What to do, in order

1. **Hand-delete five superseded files** from `outputs/match/` (code deletes nothing, D61):
   `match_rate_per_food.tsv`, `match_rate_by_reference.tsv`,
   `match_rate_ranked_skeletal_muscle_protein_with_non_protein_metabolite_pools.tsv`,
   `match_rate_ranked_skeletal_muscle_protein.tsv`, `match_rate_ranked_gorissen_2018_human_muscle.tsv`.
2. **Extract** the tarball over the repo root.
3. `python run.py match` → 22 synthetic tests, 3 currency tests.
4. `python run.py excerpt` and upload.

## 2. What changed

- **`match_rate.tsv`** — one row per food. Source, archive, id, description, category, `protein_g_per_100g`, the nine
  amino acids as published (H I L K M F T W V, the sheet's row order plus tryptophan), `eaa_g_per_100g` (their sum),
  `eaa_percent_of_protein`, then per reference `match_<id>_percent` and `limiting_<id>`, then `diff_pp_*`.
- **`match_rate_steps.tsv`** — one row per food × reference, filter on `reference`. Your sheet's walk in your order and
  names: grams (rows 12–20) · `eaa_g_per_100g` (22) · `reference_eaa_total` (A22) · `percent_of_reference_total` (23) ·
  `step3_scaled_*` (30–37) · `step7_percent_of_reference_*` (100–107) · `step7_min` (108) · `limiting_amino_acid` ·
  `step10b_*` (145–152) · `step10b_total_need_to_consume` (153) · `percent_wasted` (155) · `percent_utilized` (156) ·
  `match_rate_percent`. Steps 8–9 are not written (they cancel; the sheet computes them from the Step 3 values). A zero
  score leaves Step 10b blank, as the sheet would (#DIV/0!).
- **Headers are provenance only:** generated, version, hashes, and one `reference.<id>` line per reference carrying its
  label, file/column, scored set and **its values** — the numbers for your column A. Rule prose is gone from every file
  and lives in the docs; the standing rule is now in `conventions.md` under "Ini style".
- **Reference ids shortened:** `muscle_with_pools`, `muscle_protein_only`, `gorissen_2018`.
- Gone: `reference_label`, `scored_set`, `scored_amino_acids`, `min_data_points`, `citation`, the `ratio_*` columns,
  and the two old tables. Ranked / counts / not-scored / summary unchanged in content.

## 3. Validating in your spreadsheet

- **Old reference:** the sheet as it is. Take any row of `match_rate_steps.tsv` with `reference = gorissen_2018`, paste
  its eight grams into G12:G19 in the sheet's row order (H I L K M F T V), and G156 = `percent_utilized`; G153 =
  `step10b_total_need_to_consume`; G100:G107 = `step7_percent_of_reference_*`.
- **New reference:** add a tryptophan row 20, extend every SUM from 12:19 to 12:20, put the nine values from the
  `reference.muscle_with_pools` header line into A12:A20 (they are percent of amino acid mass; the unit cancels), and
  validate the same way against `reference = muscle_with_pools` rows.
- The test suite does the same thing on the sheet's four foods and on Pea's individual cells (I22, I23, I34, I108,
  I148, I153, I155, I156).
