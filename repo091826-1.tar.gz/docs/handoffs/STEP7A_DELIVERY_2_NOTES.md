# Step 7a — Delivery 2 R3: the literature split and `fetch-literature`

**R3 contains ONLY the eight files that changed since R1, plus these notes.** R1 is already
applied and run on your machine; R2 was withdrawn because it re-shipped
`config/literature_sources.ini` in its pre-run state, which would have wiped the three hashes
your run recorded. That file is not in this tarball at all.

## Files (9) — all replace R1 copies, none is config

```
pipeline/common.py                        literature paths become call-time functions
pipeline/fetch_literature.py              uses them
pipeline/mass_fractions.py                uses them
pipeline/comparison.py                    uses them
pipeline/literature_inventory.py          uses them
pipeline/enumerate_pool.py                uses them  <- the real fix
pipeline/non_protein_metabolite_pools.py  uses them
tests/test_comparison.py                  fixture key decisions -> sources
docs/handoffs/STEP7A_DELIVERY_2_NOTES.md  these notes
```

**Nothing in `config/` is in this tarball.** Your `literature_sources.ini` (with the three
recorded hashes) and `mass_fraction_decisions.ini` are already correct and are not touched.

## What to do

1. Extract over the repo.
2. `python run.py test`
3. If green, commit.

Nothing needs rerunning: no stage's inputs or outputs change, only where two path strings are
computed. `fetch-literature` does not need to run again — your manifest and map are current.

---

## R1's record, for reference

## The config split

- All 22 `[source.*]` sections moved **byte-unchanged** except one added line each:
  `used_by = skeletal_muscle`. Verified by diffing every section against the original.
- `mass_fraction_decisions.ini` keeps `[meta]`, the three `[columns.*]` maps and `[digest]`.
- A test asserts no `[source.*]` remains there and that every source it maps columns for
  resolves to a section in `literature_sources.ini`.
- **14 sources declare files, 8 are cited only** (`provenance_only`, `method_citation`,
  `paper_citation`, `not_used`, and Tallon 2007's gated note). A source with no `file.<n>.*`
  keys is never flagged for a missing file — there is nothing to miss. This needed no new
  config key: the absence of file keys already says it.

## `fetch-literature`

```
python run.py fetch-literature
```

Reads `config/literature_sources.ini`, finds each named file under `data/literature/<source_id>/`,
hashes it, and writes `manifest.ini`, `manifest_map.tsv` and `README.md`. It never downloads.
A missing file, a hash that does not match its pin, a `___` url, or a file whose bytes are an
HTML page under a `.pdf` name is a flag and a non-zero exit.

`protein-set` and `mass-fractions` no longer run a fetch stage, so `mass-fractions` has no
network stages left at all — `--offline` on it is now a no-op that still works.

**Run it when a literature file is added or replaced, not on a schedule.** The green light
(D78) keeps reading the manifest exactly as before.

## What the first real run will do

Three files have a **blank** `sha256` in config and always have:
`harris_1998.file.1`, `baguet_2009.file.1`, `mingrone_2001.file.1`. Under F2 a blank pin means
"never hashed", so the first run records what is on disk into
`config/literature_sources.ini` — three lines, and the only thing this stage writes into config.
Expect that in your diff; after it, those three are pinned like the rest.

If any of the three is not the file you meant, that is the moment to catch it — the hash it
records becomes the pin everything afterwards is checked against.

## `manifest_map.tsv`

One row per source, one column per category, `X` where used. Today every source reads
`skeletal_muscle`, so it is one column wide; blood adds the second in 7b by putting
`used_by = skeletal_muscle, blood` (or just `blood`) on the sources it cites, with no code change.

The first column is the **source id exactly as config spells it** — `murgia_2021`,
`moreno-justicia_2025`. The 7a handoff asked for "author and year" with `ICRP 89 2002` as an
example; the id is already the author-year name, and turning `icrp_2002` into `ICRP 89 2002`
would mean parsing the citation prose or supplying the publication number from nothing. Say the
word if you want the prettier label and I will derive it from a config key you fill in.

## Retired rules

F3, F4, F4b and F6 go with the download code. F1, F2, F2b, F5, F7 and F7b stay.

**One judgment call to review:** F6 was "a served body that is HTML is a blocked page". There is
no served body now, so F6 is retired as the handoff says — but I kept the check itself, applied
to the bytes on disk, under F5. Dropping it would have been a silent regression: it is what
catches a saved paywall page filed under a `.pdf` name, and Harris 1998 and Vega 2022 are exactly
the kind of source where that can happen. It is three lines and a flag; say so and it goes.

## Verified here / not verified here

Verified: the 13 new tests pass (driven directly — see below); all 25 modules import; everything
compiles; every source section is byte-identical to its original apart from `used_by`; the three
blank pins survive the split; the stage was run against a `data/literature/` tree rebuilt from
your uploaded `manifest.ini` — it located all 21 files across all 14 file-bearing sources and
correctly skipped the 8 cited-only ones, with no "not on disk" flags.

**Not verified: the suite under pytest.** The sandbox has no network and pytest will not install,
so the 13 tests were executed directly rather than collected by pytest. `python run.py test` on
your machine is the real check.

## Run order (done in R1)

`fetch-literature` ran 2026-09-18T06:04Z: 21 files hashed, every hash matching the existing
manifest, 8 cited-only sources skipped, 3 pins recorded, no flags.

## Naming, raised not acted on

`fetch-literature` and `fetch_literature.py` no longer fetch anything. The command name comes
from the 7a handoff and the plan, so I kept it, but by your own rule the name now describes an
action the file does not perform. `hash-literature` / `hash_literature.py` would say what it
does. It is a rename of one command and one module, cheap now and steadily less cheap later.

---

# R2 — what the first run found

`fetch-literature` itself ran clean: 21 files hashed, every hash matching your existing
manifest, 8 cited-only sources skipped, 3 pins recorded, no flags. The 13 failures were all in
the tests, from two causes, both mine.

## 1. `KeyError: 'sources'` — 12 comparison tests

`tests/test_comparison.py` replaces the whole `INPUTS` dict in its fixture. Renaming the key
`decisions` → `sources` in `comparison.py` left the fixture handing the stage a dict with no
`sources` key. Fixed in the fixture: the key is `sources` and the synthetic file it writes is
`literature_sources.ini`, which is where the citation now lives.

## 2. `KeyError: 'file.c.file.1'` — `test_contaminant_header_parsing`

This one matters more, because it is the **same defect as delivery 1 R2**, reintroduced.

`enumerate_pool.contaminant_accessions()` read
`common.DATA_DIR / "literature" / "manifest.ini"` **inside the function**, so it followed a test
that redirects `common.DATA_DIR` to a temp folder. I replaced it with the constant
`common.LITERATURE_MANIFEST_INI`, computed once at import from the real `DATA_DIR` — which
cannot follow the redirect. The stage read the repository's manifest while the test had built
its own, and the synthetic section was not in it.

The fix is the rule from R2 applied to literature: **a path derived from a root that can move is
resolved when it is used, not at import.** `common` now exposes `literature_dir()`,
`literature_manifest()` and `literature_manifest_map()` as functions, with the reason written
beside them. All five stages call them.

## An inconsistency this leaves, flagged not fixed

The literature paths are now call-time functions. The `outputs/` paths from delivery 1 are still
import-time constants — and four of them replaced expressions that used to be evaluated inside a
function:

```
mass_fractions.py:1057   excl_path  = common.PROTEIN_SET_OUT_DIR / "excluded_non_standard_alphabet.tsv"
stress.py:113            pep_path   = common.DIGEST_DIR / "theoretical_peptides.tsv"
build_protein_set.py     five write_tsv calls into PROTEIN_SET_OUT_DIR
isoform_processing_deltas.py  five more
```

No test redirects `common.OUTPUTS_DIR` for those stages today, which is why delivery 1 came back
green — they are safe by luck, not by construction. The same shape of bug is waiting there for
the first test or category that does redirect it. Making them call-time too is a mechanical
change to one file plus those call sites; it is not in this delivery because it is not what this
delivery is about. Worth its own small one when you want it.

## Verified here

The two failing tests reproduced and now pass; the 13 literature tests pass; all 25 modules
import; everything compiles. Two comparison tests fail under my hand-rolled harness both before
and after this change — an artifact of stubbing `pytest.approx`, not a real failure.
