# Project Plan — Sequence-Derived Amino Acid Standard for Human Skeletal Muscle

**Status:** Steps 1, 2, 3a, and 3b complete (2026-09-13). Step 4 ready to open.
**Revision:** 5 — see §10.
**Planning thread:** this document is the output of the planning thread. Each step below is executed in its own thread using its handoff doc in `docs/handoffs/`.
**Last updated:** 2026-09-13 (rev. 5)

---

## 1. Purpose

Replace the laboratory-sampled amino acid profile currently used as the NutriMatch™ "standard" with a **public, auditable, sequence-derived standard** computed from UniProt protein sequences and literature-derived tissue mass fractions.

The current standard has three problems:

1. It is a black box — quasi-public, not reproducible by a third party.
2. It carries laboratory error: acid hydrolysis destroys tryptophan, deamidates Asn→Asp and Gln→Glu, partially degrades Cys/Met/Ser/Thr; sampling variance between donors and muscles is unquantified.
3. It includes non-protein nitrogen (carnosine, anserine, taurine, creatine, free amino acid pool) that is not part of muscle protein.

The sequence-derived standard is exact at the protein level and carries uncertainty only in the tissue weighting, which is explicit, sourced, and propagated.

**Scope (rev. 5, D58):** the primary standard is the measured muscle-cell proteome — the contractile proteins (Tier 1, the Gene Ontology `myofibril` set) plus the support proteins (Tier 2, every protein the primary dataset quantified that is not contractile, minus a cited contaminant list) — weighted together. The contractile-only profile is reported alongside it. Water, the free amino acid pool, and non-protein metabolites are in neither tier: every weight is protein against protein. In plain terms: the contractile proteins are the ropes; the support proteins are the finished machines in the cell's water; the loose bricks on the table are not a building.

End goal: a published methods paper plus an open repository. The standard against which Match Rate is measured should not be a black box.

---

## 2. Design Principles

- **Primary sources only.** Sequences from UniProt REST with MD5 verification. Mass fractions from peer-reviewed supplementary data. No AI-estimated biological constants anywhere in the pipeline.
- **Every literature number carries a citation.** Source, table/figure, and page or supplementary file, on the same row as the number.
- **Human-editable, auditable config.** `.ini` files that a reviewer can open and check line by line. Biology lives in config, not in code.
- **Exactness is layered, and the layers are named.**
  - **Layer A** — per-protein residue composition from sequence. Exact. Zero uncertainty.
  - **Layer B** — mass fraction of each protein in the tissue, by fiber type. Literature-derived. Uncertainty is quantified and propagated.
- **Scope is tiered, and tiers are justified in writing** rather than by convention.
- **Corrections are welcome.** Anything found wrong gets fixed and logged in the decisions log (§8).
- **Provenance governs everything.** `PROVENANCE.md` in the repository is the rule this plan operates under: every value is an author decision, a citation, or a computation. An assistant's recollection is never a source. (Added rev. 2.)

---

## 3. Architecture

```
UniProt REST ──► fetch ──► sequence store (.ini, MD5-verified)
                                    │
accessions.ini ─────────────────────┤  Layer A
segments.ini (processing flags) ────┤
                                    ▼
                          composition engine
                    (residue counts → mass vectors,
                     residue-mass AND free-AA-mass conventions)
                                    │
mass_fractions_<fiber>.ini ─────────┤  Layer B (cited per row)
fiber_mixes.ini ────────────────────┤
                                    ▼
                          aggregation + Monte Carlo
                    (per fiber type, per muscle, ranges, plots)
                                    │
                                    ▼
                          STANDARD (versioned, published)
                                    │
USDA food table ────────────────────┤
match formula ──────────────────────┤
                                    ▼
                          Match Rate for any food
```

### Repository layout (target — superseded by `docs/conventions.md` in the repository as of rev. 2; kept for orientation)

```
muscle-aa-standard/
├── README.md
├── pyproject.toml
├── config/
│   ├── accessions.ini            # Step 1 — what proteins, which isoform, which tier
│   ├── segments.ini              # Step 1/2 — processing flags per accession
│   ├── mass_fractions/           # Step 3 — one file per fiber type, cited per row
│   └── fiber_mixes.ini           # Step 3/4 — fiber-type proportions per muscle
├── data/
│   ├── sequences.ini             # Step 2 — auto-generated, MD5-verified
│   ├── literature/               # Step 3 — supplementary tables as downloaded, with provenance
│   └── usda/                     # Step 6
├── src/muscle_aa/
│   ├── fetch.py                  # Step 2
│   ├── composition.py            # Step 2
│   ├── aggregate.py              # Step 4
│   ├── uncertainty.py            # Step 4
│   ├── validate.py               # Step 5
│   ├── match.py                  # Step 6
│   └── plots.py                  # Step 4/5
├── tests/
├── outputs/                      # standard tables, figures — versioned
└── docs/
    ├── 00_project_plan_R<n>.md   # this file; <n> = revision, see §10
    ├── handoff_template.md
    ├── handoffs/                 # one per step
    ├── decisions.md              # running log, see §8
    └── methods.md                # written incrementally, becomes the paper's Methods
```

---

## 4. Decisions Already Made (planning thread)

*Authoritative copy: `docs/decisions.md` in the repository. This table is the planning-thread seed (D1–D12); D13 onward live only there.*

| # | Decision | Rationale |
|---|----------|-----------|
| D1 | Standard is built first; Match Rate module comes after (Step 6). | The standard is the input to the match calculation; must exist before the calculation is formalized in code. |
| D2 | Two-layer model (Layer A exact / Layer B cited). | UniProt gives composition, not abundance. Naming the layers makes the uncertainty honest and publishable. |
| D3 | *(scope superseded by D58 — the primary standard is contractile + support; the contractile-only profile is reported alongside)* Tier 1 = myofibrillar (contractile) proteins. | Original scoping concept was muscle fiber; MPS literature measures myofibrillar synthesis separately; resistance training primarily drives the myofibrillar fraction. |
| D4 | *(absorbed by D56/D58 — Tier 2 is the measured remainder and part of the primary standard)* Tier 2 = the support proteins. | Originally a sensitivity set for comparison with whole-tissue lab standards; the combined profile is now that comparison. |
| D5 | *(superseded by D20 — the pool is computed from the category; no protein is placed by hand)* | — |
| D6 | Fiber-type-specific entries are used, not proxies. | Satisfied by construction: the computed pool contains each paralog as its own entry; fiber type itself is a Layer B quantity (D17). |
| D7 | Residue counts are the stored ground truth; both mass conventions are derived. | Residue-in-chain mass ≠ free amino acid mass (one H₂O). USDA food tables and lab AAA report free-AA g/100 g. Match Rate must use the free-AA convention to be consistent with the food data. |
| D8 | Keep the `in_master_molecule` / `in_triple_helix`-style segment-flag architecture from the collagen pipeline. | Mature vs precursor is a small effect for cytosolic muscle proteins (initiator Met, actin N-terminal processing, isoform choice) but the architecture is already proven and the collagen tier reuses it. |
| D9 | Layer B primary source = quantitative human proteomics (single-fiber, by fiber type; whole-muscle deep proteome). Classical biochemical fractionation values are the cross-check. | Proteomics gives human, fiber-type-resolved abundance. Classical fractionation gives direct mass measurement of the major structural proteins. Agreement between the two is itself a validation result. |
| D10 | Literature is researched in-thread (Step 3), not deferred as "verify later". | Public scrutiny standard. |
| D11 | Accession list (Step 1) is settled before mass fractions (Step 3). | Can't weight what hasn't been enumerated. |
| D12 | The starting 9-protein table is treated as unverified and is not an input to anything. | Provenance unknown; resembles a renormalized classical myofibrillar fractionation but cannot be reconstructed. |

---

## 5. Steps

Each step = one thread + one handoff doc. A step is done when its acceptance criteria are met and its outputs are committed.

### Step 0 — Repo scaffold and conventions — **DONE** (folded into Step 1; repository `uniprot-standard`)
- **Goal:** Package skeleton, config schemas, citation schema, doc templates.
- **Deliverables:** Directory layout above; `.ini` schema documented in `docs/conventions.md`; `pyproject.toml`; empty test harness; `decisions.md` seeded from §4.
- **Size:** Small. Can be folded into the start of Step 1 or 2 if preferred.

### Step 1 — Protein set — **DONE 2026-09-11**
- **Goal (as executed, D22):** the protein set derived by code from the seed words: exact-name Gene Ontology lookup → UniProt query → fetch and verify → field-based rules → generated config.
- **Result:** Tier 1 = `myofibril` GO:0030016, 242 entries; Tier 2 = `sarcoplasm` GO:0016528, 87 entries; 26 in both; 303 unique, all MD5-verified. Gene Ontology release 2026-07-26, UniProt release 2026_03. Zero open flags. Config byte-identical on two machines.
- **What changed from the plan:** no hand-written accession list and no isoform selection (D16 — canonical always, deltas disclosed); no fiber-type field (D17); no literature in this step (D22). Decisions D13–D24.
- **Handoff:** `docs/handoffs/01_protein_set_handoff.md`; narrative in `docs/step1_report.md`.

### Step 2 — Composition (Layer A) — **DONE 2026-09-12**
- **Goal (as executed):** per-protein amino acid composition from sequence, by arithmetic, with every constant fetched. No aggregation.
- **Result:** `outputs/composition/amino_acid_composition_per_protein.tsv`, 606 rows (303 entries × mature chain / full gene product): residue counts, both mass conventions as fractions, molecular weight. Masses fetched from PubChem by name (twenty amino acids to 2 decimals; water 18.015; H₂ 2.016), the letter-to-name table parsed by code from the IUPAC-IUBMB Table 1 page; the only author-written input is two URLs and one rule (`config/composition_decisions.ini`). Water identity holds to 2.3 × 10⁻¹⁰ g/mol. Two disclosures, no decision attached: processing (92 entries; 9 lose > 10 % of mass; largest single-amino-acid shift 0.051) and post-translational modifications (2,742 sites in 252 entries, priced from UniProt's PTM vocabulary; median 0.5 % of MW, max 7.2 %; glycosylation unbounded). Decisions D25–D31. 56 tests.
- **What changed from the plan:** no fetcher (Step 1's harvest reused); no hand-written mass table or seed; TSV not CSV; the mass table lives in `data/pubchem/`, not `config/`; tests use synthetic fixtures (the ExPASy ProtParam cross-check is a manual item carried to the author).
- **Handoff:** `docs/handoffs/02_composition_handoff.md`; narrative in `docs/step2_report.md`.

### Step 3a — Mass fractions: sources and rules — **DONE 2026-09-12**
- **Goal (as executed):** every Layer B input on disk and hashed; every rule for turning the primary file into weights decided with the file open; the Layer A digest computed.
- **Result:** Primary dataset A1 (Murgia et al. 2021, Dataset 1: iBAQ-type values normalised to ACTA1, median per fiber type, 61 pure fibers, 3,857 rows, gene names only). Cross-checks: A5 (Moreno-Justicia 2025, ratios), A4 (Deshmukh 2021, slow/fast ratios), H1 (Carroll 2004, human MHC and actin by quantitative SDS-PAGE). All non-human data sources removed. 9 files in `data/literature/`, all SHA-256 pinned, `fetch_literature.py` flags 0. `digest.py` flags 0: 303 entries, 18,039 theoretical peptides, 141 sharing pairs, density median 0.530 peptides/kDa. Decisions D31–D49.
- **What changed from the plan:** no TPA (raw intensities not published); no rabbit/mouse cross-check; between-fiber spread taken from Dataset 1's SD columns (no PXD006182 reprocessing); the join is by gene name with summed protein groups (D47) and a shared-group rule (D48); "giant proteins" and "isoform families" replaced by computed density rank and shared-peptide pairs (D43, D44).
- **Handoff:** `docs/handoffs/03a_close_and_03b_handoff.md`.

### Step 3b — Mass fractions: weights — **DONE 2026-09-13**
- **Goal (as executed):** every weight traceable to a row of the primary dataset by a stated formula; the cross-checks reported as numbers per method; the scope of the standard decided with the numbers in hand.
- **Result:** `pipeline/mass_fractions.py` (rules B0–B8), `literature_inventory.py` (I1–I5), measured Tier 2 in `enumerate_pool.py` (M1–M5), rules R2e and R5 in the protein-set build. Weighted set 3,788 entries (242 contractile, 3,546 support). Combined standard (D58): contractile share 71.7 / 72.8 / 71.6 % in types I / IIa / IIx (≈ 2.5 : 1); titin the largest entry at ~20 %. Gel comparison (Carroll 2004) reported per method without attribution (D54): MHC : actin quotients 1.64 / 1.63 (iBAQ × MW) and 2.46 / 1.77 (Deshmukh 2021 intensity share). Family bounds (D55), R5 exclusions (six selenoproteins, < 0.01 %), Moreno-Justicia ratio check (2,303 entries, median |log2| disagreement 0.58). Decisions D50–D60. 80 tests; master log per run.
- **What changed from the plan:** Tier 2 redefined from measurement (D56) and folded into the primary standard (D58); no TPA; the gel comparison is a comparison, not a calibration; all rankings and summaries are generated files (`combined_entries_ranked.tsv`, `tier<N>_entries_ranked.tsv`, `mass_fractions_summary.ini`); `docs/pipeline_map.md` added.
- **Handoff:** `docs/handoffs/04_aggregation_handoff.md`; narrative in `docs/step3b_report.md`.

### Step 4 — Aggregation and uncertainty — **NEXT**
- **Goal:** The standard itself, with ranges: the combined (D58) and contractile-only profiles per fiber type, both mass conventions, their per-amino-acid difference, Monte Carlo over the Layer B intervals, the family/isoform/processing/PTM bounds carried, the gel scenario (D54b), EAA subset tables, plots.
- **Handoff:** `docs/handoffs/04_aggregation_handoff.md`.
- **Decisions owed:** D46 (I / IIa / IIx vs slow / fast); a fiber-mix source if per-muscle profiles are reported.

### Step 5 — Validation against laboratory data
- **Goal:** Show where and why the sequence-derived standard differs from lab-sampled human muscle.
- **Deliverables:** Compiled lab AAA values for human skeletal muscle (cited); predicted-vs-measured figure; per-amino-acid attribution of deviations (Trp destruction, Asn/Gln deamidation, Cys/Met/Ser/Thr loss, non-protein nitrogen contributions to His etc.); Tier 1 vs Tier 1+2 comparison.

### Step 6 — Match Rate
- **Goal:** Formalize the Match Rate calculation in code against the new standard.
- **Deliverables:** Formula written out in `docs/methods.md`; `match.py`; USDA ingestion in the free-AA convention; Match Rate for every food in the database; re-scored reference foods (whey, pea, egg, steak, current blend) under old vs new standard.
- **Input needed from Anthony:** the current spreadsheet formula.

### Step 7 — Paper
- **Goal:** Methods paper.
- **Deliverables:** `docs/methods.md` assembled from per-step docs; figures from Steps 4/5; supplementary data = the config files themselves.

---

## 6. Conventions (to be formalized in Step 0)

**Config format:** `.ini` via `configparser`. One section per entity. Free-text `note` and `justification` keys allowed. Comments with `#`.

**Citation schema** (every literature-derived number):
```
value     = 0.431
unit      = mass_fraction_of_tier
source    = Author et al. YEAR, Journal Vol:pages, DOI
location  = Supplementary Table S3, column "iBAQ_typeI"
retrieved = 2026-09-XX
note      = optional — conversions applied, caveats
```

**Mass conventions:**
- `residue_mass` — in-chain residue mass (free AA minus 18.015 Da). Sums to protein MW.
- `free_aa_mass` — free amino acid mass. Sums to > protein MW. This is the USDA / lab AAA convention and the one Match Rate uses.
- Both reported. Ground truth is residue count.

**Accession identity:** `ACCESSION` or `ACCESSION-N` for a specific isoform. Sequence version recorded. MD5 recorded and checked against UniProt's published checksum.

---

## 7. Open Questions (carried forward, owned by the step that resolves them)

| Question | Resolved in |
|----------|-------------|
| Isoform choice for any entry | Resolved: none is made (D16); bounds disclosed, revisited in Step 3 only if material after weighting |
| Whether any specific entry belongs in the set | Resolved: membership is computed (D20); abundance is a Step 3 quantity, never a Step 1 rule |
| Criterion for "myofibrillar" | Resolved: the Gene Ontology term matched by exact name (D13); neighbours recorded as sensitivity |
| Initiator Met and N-terminal processing | Resolved: `Chain` feature rule (D19, D24); bound disclosed (0.046 max) |
| 3-methylhistidine and all PTMs | Resolved: counted as the encoded residue; mass disclosed per entry (D28); the dietary-precursor argument and citation → paper step |
| Cysteine vs USDA "cystine"; whether Match Rate may ignore cysteine | Step 6 (D27) |
| Isoform, processing, and PTM bounds — material after weighting? | Resolved: `weighted_bounds.tsv` — largest Tier 1 isoform bound 0.0055, processing 0.0002, PTM 0.0014; carried to Step 4 as bounds |
| Glycosylation mass (unbounded from the entry) | Resolved: Σ w over glycosylated entries 2–3 % of contractile, 17–19 % of support; stated as a limitation |
| Which proteomics datasets | Resolved: A1 primary (D32); A4, A5, H1 cross-checks (D34, D36, D39) |
| How to treat an iBAQ-vs-gel (Carroll 2004) disagreement | Resolved: reported per method without attribution (D54); the profile under rescaled weights is a Step 4 scenario (D54b) |
| Tier 2 definition | Resolved: the measured remainder (D56); part of the primary standard (D58) |
| Pool completeness against the Layer B abundance ranking | Resolved: 121 dataset genes outside the pool, listed with mapping outcome; sensitivity by rank in Step 4 |
| Handling of the 26 dual-tier entries | Resolved: moot — Tier 2 is the remainder, so no entry is in both |
| Fiber-type proportions for named muscles — which source(s). | Step 4, after D46; needs IIa/IIx split and per-type fiber area; Johnson 1973 is a citation only (D40) |
| Momenzadeh 2023: which table (S2 / S3) matches the paper's text on MYH4 | Paper step |
| Structural titin : MHC anchor from sarcomere stoichiometry | Paper step |
| Match Rate delivery layer: proportion × absorption × burn, surplus above proportion counted as surplus | Step 6 |
| `data/uniprot_sequences.ini` → tables | Clean-up after Step 4 |
| Which lab AAA datasets of human muscle to validate against. | Step 5 |
| Match Rate formula — EAA-only or all AA; normalization; basis. | Step 6 |

---

## 8. Decisions Log

Maintained in `docs/decisions.md`. Seeded from §4. Every subsequent decision made in a step thread is appended there with date, step, and rationale.

---

## 9. Thread Protocol

1. Open a new thread named for the step (e.g., "Step 1 — Accession list").
2. Paste the handoff doc as the first message.
3. Work only that step. Anything out of scope goes into the handoff's "Deferred / raised" section, not into the work.
4. On completion: update `decisions.md`, write the next step's handoff (or update the draft), tick this plan's step status and add a row to §10, commit.
5. Return to the planning thread only to re-plan, not to do work.

---

## 10. Revision Log

| Rev | Date | Change |
|---|---|---|
| 1 | 2026-09-09 | Planning thread output. |
| 2 | 2026-09-11 | Step 0 and Step 1 marked done; Step 1 goal restated as executed (D22); Step 2 rewritten (harvest already done); §7 open questions resolved or moved to Step 3; `PROVENANCE.md` added to §2; §3 layout deferred to `docs/conventions.md`; §4 deferred to `docs/decisions.md`; D5 marked superseded; §9 step 4 now includes the plan tick. |
| 3 | 2026-09-12 | Step 2 marked done and restated as executed (D25–D30); Step 3 marked next with its handoff; §7 Step 2 questions resolved or moved; new §7 rows for cysteine/Match Rate, weighted bounds, glycosylation. |
| 4 | 2026-09-12 | Step 3 split into 3a (done: sources, rules, digest; D31–D49) and 3b (next: tables). §7 Step 3 questions resolved or moved to 3b/4. Rev. 3 row corrected: Step 2 decisions are D25–D30 in `decisions.md`, not D31. |
| 5 | 2026-09-13 | Step 3b marked done (D50–D60); §1 scope restated under D58 (contractile + support); D3 and D4 rows annotated; Step 4 marked next with its handoff; §7 rows resolved or moved; four new §7 rows. |
