# Step 3a — Close-out and Step 3b Handoff

**Project:** Sequence-Derived Amino Acid Standard for Human Skeletal Muscle
**Governing rule:** `PROVENANCE.md`
**Status:** 3a COMPLETE 2026-09-12. `fetch_literature.py` flags: 0 (17:43Z); `digest.py` flags: 0 (19:22Z).
**Supersedes:** `03a_mass_fraction_sources.md` (planning thread) and the earlier draft of this file. Every number here is either from a file on disk (`data/literature/manifest.ini`) or an author decision.

---

## 1. What 3a produced

| Artefact | State |
|---|---|
| `config/mass_fraction_decisions.ini` | hand-written; 10 sources, roles D-numbered; column map transcribed from Dataset 1; digest rules cited; no protein, no abundance number, no non-human data source |
| `data/literature/` | 9 files, all SHA-256 pinned, `flags: 0` (run 2026-09-12T17:43Z); 5 obtained by hand, recorded as such in `manifest.ini` and `README.md` |
| `pipeline/fetch_literature.py` | rules F1–F7 |
| `pipeline/digest.py`, `tests/test_digest.py` | rules G1–G5; 8 tests green; run 2026-09-12T19:22Z, flags 0 |
| `docs/methods.md` §"Mass fraction derivation" | drafted; digest placeholders filled; remaining ⟨placeholders⟩ filled in 3b |

## 2. decisions.md — append verbatim

| # | Step | Decision | Rationale |
|---|------|----------|-----------|
| D31 | 3a | Layer B quantity is iBAQ × MW, normalised within tier (Σ Tier 1 = 1; Σ Tier 2 = 1). TPA is not computed. | A1 publishes iBAQ-type values normalised to ACTA1 (= 100 000 in every column of Dataset 1); the ACTA1 factor cancels in the within-tier ratio. Raw intensities are not published, so TPA is not computable from the file. |
| D32 | 3a | A1 (Murgia et al. 2021, Skelet Muscle 11:24; Dataset 1) is the primary and only Layer B weight source. | The only human, fiber-type-resolved dataset found that publishes a cross-protein-comparable quantity per fiber type. |
| D33 | 3a | A2 (Murgia et al. 2017) is provenance only. | Same raw data (PXD006182); A1 is its young-donor reanalysis. Not independent. |
| D34 | 3a | A5 (Moreno-Justicia et al. 2025) is a fiber-type-ratio cross-check; never a weight source. | DIA-NN protein-group LFQ, proteotypic peptides only; 1038 fibers, 5 donors. |
| D35 | 3a | A3 (Momenzadeh et al. 2023) is a method citation only (iBAQ vs MaxLFQ on the same fibers, Tables S2/S3). | Two donors, ~744 proteins. |
| D36 | 3a | A4 (Deshmukh et al. 2021) is a two-class (slow/fast) ratio cross-check, PRE-training columns only. Quant confirmed MaxLFQ. | Independent lab and workflow; pooled fibers; fast pools ~80 % MYH2 / ~20 % MYH1 (A4 Fig. 1f). |
| D37 | 3a | B1 (Wiśniewski 2017), B4 (Schwanhäusser 2011), B5 (Cox 2014) are method citations. | TPA; iBAQ; MaxLFQ and protein-group quantification. |
| D38 | 3a | Rakus et al. 2015 and Wiśniewski et al. 2015 are not used. | Mouse. No question they answer that a human source or a method citation does not. |
| D39 | 3a | The classical (non-MS) cross-check is human-only: H1 (Carroll, Carrithers & Trappe 2004, J Muscle Res Cell Motil 25:55) — MHC and actin per total fiber protein by quantitative SDS-PAGE against standards, types I and IIa. Yates & Greaser 1983 (×2) and Ohtsuki et al. 1986 (rabbit / mixed vertebrate) are not used. Trappe et al. 2002 (Muscle Nerve 25:289; titin/nebulin) was read and rejected: uncalibrated densitometry, no normalising protein, arbitrary units (its Methods and Results). | A human, fiber-type-resolved, weighed measurement exists; a non-human comparison would confound species with method. No usable human weighed-mass source for titin or nebulin was found; the giant-protein check is therefore the disclosed density rank (D43) with no external anchor — stated as a limitation. |
| D40 | 3a | Johnson et al. 1973 (J Neurol Sci 18:111) is a paper citation for between-subject and between-muscle variation in fiber-type proportions. It is not a Layer B input and not the Step 4 fiber-mix source (Type I/II only, count not area). No file. | Motivates confining tissue-composition variance to Layer B. The Step 4 fiber-mix source is chosen when D46 is decided. |
| D41 | 3a | The per-fiber-type standard is defined on A1's pure fibers (≥ 80 % one MYH); hybrids are handled in the Step 4 fiber-mix step. | Clean definition; hybrid composition is a mixing problem. |
| D42 | 3a | A cross-check is admitted only with a named question it answers; otherwise it is dropped. | Every discrepancy must be attributable. |
| D43 | 3a | `pipeline/digest.py` is a Step 3 stage. Theoretical-peptide density per entry is ranked and disclosed; no threshold is applied and no A1 value is adjusted. | D16 pattern: disclose, don't adjudicate. Replaces any hand-named list of "giant proteins". |
| D44 | 3a | Shared-peptide families are computed by `digest.py` from sequence; A1-vs-A5 ratio disagreement within a family is a per-family Layer B uncertainty term. | Replaces any hand-named list of isoform families. |
| D45 | 3a | Between-fiber spread per fiber type is taken from Dataset 1's `Standard deviation` columns. PXD006182 is not reprocessed. | The spread is published; reprocessing is unnecessary. Caveats disclosed: SD paired with a median; 2X rests on 13 fibers. |
| D46 | 3a | Whether the standard reports I / IIa / IIx or slow / fast is owned by Step 4. | A5 found no pure 2X at the protein level; A1's 2X column rests on 13 fibers. Step 1 is closed; fiber mixes are a Step 4 object. |
| D47 | 3a | Dataset 1 rows sharing one gene name are **summed** to give that gene's value; the share contributed by all but the largest row is written per gene as a disclosure. | The rows are MaxQuant protein groups of one gene product; summing involves no selection. 85 gene names occur on > 1 row (e.g. five for TTN, four for NEB, two for MYH2). |
| D48 | 3a | A Dataset 1 row whose gene-name cell lists several genes (`;`) is split on `;`. Members not in the pool are ignored. One member in the pool → the value goes to it, marked `shared_group`. Two or more in the pool → the value is divided in proportion to each member's own single-name rows (equally if none has one), and each member carries the whole row as `w_high`. The total signal share arriving through shared rows is printed per tier and fiber type. | The instrument cannot attribute those peptides; the label can be split, the number cannot. 139 such rows; 3.0 % of all summed medians, dominated by ubiquitin, histones, and mitochondrial subunits — expected to be far smaller within Tier 1. |
| D49 | 3a | Digest rules: trypsin after K/R, peptides of 6–30 residues, 0 missed cleavages (B4 as restated in Nature Sci Data 2018;5:180128). A1 does not state whether cleavage before proline was allowed; `digest.py` computes both (`cleave_before_proline = both`), takes Trypsin/P as primary, and writes the per-entry and summary difference. | Cited where a source exists; disclosed where none does. |

## 3. conventions.md — append

**B-rules (`pipeline/mass_fractions.py`, Step 3b)**
- **B0 Source** — `config/mass_fraction_decisions.ini` `[source.*]`; every file read is first re-hashed and compared with `data/literature/manifest.ini`; mismatch stops the run.
- **B1 Identity** — `identity_kind = gene_name`: exact symbol match against the `gene` column of `config/accessions.ini` after stripping whitespace. Multiple dataset rows per gene → D47. Multi-gene cells → D48. A pool gene with no row → w = 0, listed. A dataset gene with no pool entry → completeness list.
- **B2 Quantity** — w_i = v_i · MW_i / Σ_tier (v_j · MW_j); v from the mapped median column; MW from Step 2, `segment_set = master`.
- **B3 Fiber type** — the dataset's own columns and purity threshold; never re-derived.
- **B4 Missing** — `NaN` (with valid values = 0) → 0, listed; never imputed.
- **B5 Spread** — the mapped SD column per fiber type, carried per row for Step 4 (D45).

**F-rules (`pipeline/fetch_literature.py`)** — F1 placeholder URL = flag; F2 hash pinned on first fetch, mismatch = flag, nothing written; F3 bytes on disk == bytes served; F4 HTTP failure = flag; F5 hand-obtained file declared `obtained = manual`, hashed in place; F6 HTML served where a document was expected = flag, nothing written; F7 stored name = URL basename (Windows-illegal characters → `_`), served name kept in the manifest.

**G-rules (`pipeline/digest.py`)** — G1 every parameter cited or stop; G2 cleavage rule incl. `both`; G3 length window and missed cleavages; G4 full canonical sequence, MW from the full-product row; G5 nothing named, nothing filtered.

## 4. Dataset 1 as read (for methods.md and 3b)

`data/literature/murgia_2021/13395_2021_279_MOESM1_ESM.xlsx`, sha256 `223f8753…10d2a`. One sheet (`Sheet1`), headers on row 3, 3 857 data rows, 14 columns: three medians, three SDs, three valid-value counts, `Gene names`, a blank column, three percent-of-max columns. Identity by gene name only; no accession column. ACTA1 = 100 000 in all three median columns. 491 median cells are the string `NaN`, each with valid values = 0. 85 gene names occur on more than one row; 5 gene-name cells are blank; 139 cells list several genes separated by `;` (3.03 % / 3.04 % / 2.86 % of summed medians for I / 2A / 2X).

## 5. Step 3b handoff

**Goal.** From Dataset 1 + `accessions.ini` + Step 2 MW, generate the per-fiber-type mass-fraction config and the tables a person reads to judge it; run the cross-checks and the carried checks; fill the ⟨placeholders⟩ in methods.md from run records.

**`pipeline/mass_fractions.py` — outputs (all generated, all with a header naming inputs and hashes):**

| File | Contents |
|---|---|
| `outputs/mass_fractions/joined.tsv` | one row per pool accession: gene, tier (`1`, `2`, `1;2`), median I/IIa/IIx, SD I/IIa/IIx, valid values, `match_rule` (single / summed:n / shared_group / shared_split), summed-row minor share, w_I, w_IIa, w_IIx, w_high per type. **This is the human-readable "Tier 1 as measured" table; filter on `tier`.** |
| `outputs/mass_fractions/dataset_rows_outside_pool.tsv` | every Dataset 1 row matching no pool entry, ranked by v·MW share of the whole file — the completeness check from Step 1 and the evidence for the Tier 2 decision |
| `outputs/mass_fractions/unmatched_pool_entries.tsv` | pool accessions with no Dataset 1 row (w = 0) |
| `outputs/mass_fractions/shared_groups.tsv` | every `;` row touching the pool, with the D48 outcome |
| `outputs/mass_fractions/ratio_check_A5.tsv`, `ratio_check_A4.tsv` | per protein (and per digest family), A1 slow/fast ratio vs A5 and vs A4 (PRE) |
| `outputs/mass_fractions/classical_check_H1.tsv` | MHC:actin ratio from iBAQ×MW (I, IIa) vs H1's values; H1's numbers transcribed into `config/classical_fractionation.ini` with page/table, never into code |
| `outputs/mass_fractions/weighted_bounds.tsv` | isoform, processing, PTM bounds × w_i; largest per amino acid; Σ w over glycosylated entries; Σ w over cardiac-branch-only entries |
| `outputs/mass_fractions/tier2_candidates.tsv` | Dataset 1 rows not in Tier 1, ranked — input to the Tier 2 decision |
| `config/mass_fractions/{I,IIa,IIx}.ini` | generated; per accession: value, unit, source (A1 + file hash + sheet + header + row index), retrieved, valid_values, sd, w_low, w_high, match_rule |
| `outputs/mass_fractions/summary.ini`, `outputs/logs/mass_fractions_<UTC>.log` | counts, shared-row share per tier, flags |

**Tests.** Regenerated config equals disk; Σ w = 1 per tier per fiber type; no accession in code; header-whitespace stripping recorded.

**3b decisions to make (with the tables in front of you).** Tier 2: keep the ontology set or redefine from measurement (`tier2_candidates.tsv`). Any H1 comparison failure: disclosed, not corrected (D43 pattern). A4 units as used.

**Reading order for the A4 rar files.** Extract in code at read time; the extracted member's hash goes in the run log; nothing extracted is stored in `data/literature/`.

## 6. Deferred / raised

- **Paper step:** A1's two selections (61 of 152 fibers, pure ≥ 80 % MYH, all three types; Dataset 2 is the paper's 404-protein analytical subset, the standard uses Dataset 1). Neither biases the weights; the first sets n per column. Johnson 1973 cited for tissue-composition variance (D40). Trappe 2002 examined and rejected (D39). No human weighed-mass anchor exists for titin/nebulin — limitation.
- **Step 4:** I/IIa/IIx vs slow/fast (D46); fiber-mix source with IIa/IIx split and per-type fiber area, to be searched once D46 is decided; SD-with-median caveat (D45).
- **Step 1 (note only):** within-tier normalisation makes Tier 1 membership propagate into every Tier 1 weight.

## 7. Run record

`digest.py`, 2026-09-12T19:22:30Z, rules D49: 303 entries; 18,039 distinct theoretical peptides; 530 shared by ≥ 2 entries across 141 pairs (47 pairs share a single peptide); 34 connected families, largest 12 (the ten MYH entries plus two single-peptide attachments). Peptides per kDa: median 0.530, MAD 0.061, range 0 (one 35-residue entry with no in-window peptide) to 0.942. Proline-rule sensitivity: median 1.1 %, ≥ 10 % for 31 entries, maximum 23.8 %.

Outputs: `outputs/digest/{theoretical_peptides,density_ranked,shared_peptides,shared_pairs,families}.tsv`, `digest_summary.ini`; log `outputs/logs/digest_2026-09-12T192230Z.log`.

**Consequence for 3b:** the family check works from `shared_pairs.tsv` (n_shared_peptides and shared fraction), not from connected components — 47 of 141 pairs are single-peptide links, and the two largest components are each two real families bridged by one peptide (MYH core + AHNAK/ASB2; TPM1-4 + ACTN1-4 via TPM2–ACTN2). The shared-fraction cutoff, if any, is a 3b decision made with that table open.
