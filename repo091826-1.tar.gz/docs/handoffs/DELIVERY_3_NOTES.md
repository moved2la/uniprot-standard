# Step 6 — delivery 3

**Date:** 2026-09-17 · **Decisions:** D86 (the scored set), D87 (the formula, transcribed), D88 (two scripts)
**Contents:** 20 files — 14 changed, 5 new, plus this note. Extract over the repo root; every path is relative to it. Nothing to delete.

## 1. What to do, in order

1. **Extract** the tarball over the repo root (14 files overwrite, 5 are new).
2. `python run.py comparison` — first, because `comparison.py`'s output header text changed (item 3.1 below) and
   its currency test compares the files on disk with a fresh build. One run refreshes `outputs/comparison/`.
3. `python run.py match` — needs `outputs/standard/` (both standards) and `outputs/usda/` on disk, which you have.
   Writes `outputs/match/` (eight files: the per-food table, the wide table, three ranked tables, the limiting
   counts, the not-scored list, the summary) and runs the tests: 19 synthetic match tests, 3 currency tests.
4. `python run.py excerpt` and upload the tarball — the spec now covers `outputs/match/` and the mass-balance file.

## 2. What is in it

- **`pipeline/match.py`** — the formula (D87, rule M1): both sides as shares of the scored set, the smallest of
  (food share / reference share) is the score, its amino acid the limiting one. Protein content never enters.
  The spreadsheet's Steps 8–10b reduce to the same number and are carried as the `ratio_<letter>` columns (M5).
- **`config/match_rate.ini`** — three references (primary: with non-protein metabolite pools; the protein-only column;
  Gorissen 2018's human muscle on its own eight rows), two scored sets (the FAO nine with SAA → Met and AAA → Phe,
  D86; the paper's eight), the two food tables, the version label. Nothing is named in code.
- **`config/food_amino_acids_other_sources.csv`** — your hand-maintained table, header-only as shipped. Columns in
  `docs/conventions.md` ("Hand-written files"). One row per food; `label` unique, `source` required.
- **`tests/test_match.py`** — the transcription test first: the spreadsheet's four foods reproduce G156:J156 to the
  last digit, and a literal re-run of Steps 3–10b equals the minimum ratio. Then M1–M5 on synthetic foods.
- **Docs** — `formula.md` "Match Rate" (pea worked example, checkable cell by cell against the sheet); `methods.md`
  §Match Rate; rules M1–M6 in `conventions.md`; D86–D88 in `decisions.md`; pipeline map (three new subgraphs and the
  `match` table); README; handoff (deliveries 2 and 3 logged, open list rewritten).

## 3. Review items from the other thread, fixed here

1. `comparison.py`: the docstring and the output header said "sixteen rows, W/D/N excluded" (pre-D85). Now they
   describe the declared set and list every excluded letter, pointing at the row that carries its reason.
2. X4's essential-row grouping was eight names in code. It is now `essential_rows` in
   `config/gorissen_2018_comparison.ini [values.human_muscle.location]`, with the paper's location (p. 1687), read
   by the stage; a config without it stops. `match.py` reads the same key for the old reference's scored set.
3. Three locations corrected against the PDF (the 84 % sentence, tryptophan, asparagine/glutamine), and a
   `units_note`: the paper quantifies against free amino acid standards and states no residue conversion, so the
   values are read as free-amino-acid masses — the convention the mass balance depends on, stated as an interpretation.
4. `docs/gorissen_comparison.md` §3 and §5 in report mode; D85's rationale no longer says the mass balance "settles
   it" — it is a bound (uncorrected hydrolysis losses mean recovery below 100 % is expected under any protein figure).
   The zeros decision stands on the proline argument.

## 4. Sandbox smoke run (Gorissen reference only — the standards are not in the tarball)

5,156 foods; 5,019 scored; 137 not scored (a scored amino acid unreported); 6 at zero; median 74.7 %.
Phenylalanine limits 39 % of foods under the old reference, histidine 23 %, lysine 23 %, methionine 10 %.
Your run adds the two calculated references and the wide old-beside-new table.
