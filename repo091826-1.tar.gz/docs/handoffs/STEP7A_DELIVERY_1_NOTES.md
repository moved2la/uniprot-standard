# Step 7a — Delivery 1 R3: the outputs/ move

**R3 fixes the three test failures from the R2 run.** Two were stale assertions; one was a real
defect in `common.standard_path()`. Detail at the bottom under "What R3 changed".

**Scope:** paths only. No stage changes what it computes, what it reads from `config/` or
`data/`, or what it writes into a file. Every regenerated file should be identical below its
header to the copy in `outputs_original/`, and `compare_output_trees.py` is how that is shown.

**Not in this delivery** (deliberately split from the handoff's proposed order, so that any
difference the comparison reports is unambiguously a path bug and nothing else):
`config/literature_sources.ini`, the `fetch-literature` command, `manifest_map.tsv`,
per-stage hashing, the placeholder rule, per-stage excerpt specs, provenance-only headers,
`run_order.md` and the docs. Those are deliveries 2 onward.

---

## Before you run

1. **`outputs_original/` must sit outside the repository** — a sibling of `uniprot-standard/`,
   not inside it. `.gitignore` has no entry matching it, so inside the repo git sees 111
   untracked files. The commands below assume `../outputs_original`.
2. **`outputs/` in the repo should be empty.** It is, if you have not run anything since the
   rename.
3. **Rescue `match_rate_filtered.xlsx`** if you have not already — it is in
   `outputs_original/match/`, it is yours, and nothing regenerates it.

## Files in this delivery (18)

Drop in place, overwriting. No deletions, no renames.

```
pipeline/common.py                          the new constants, the placement map, write_text_file
pipeline/aggregate.py                       write through standard_path
pipeline/uncertainty.py                     write + read through standard_path
pipeline/stress.py                          write + read through standard_path
pipeline/non_protein_metabolite_pools.py    write + read through standard_path
pipeline/plots.py                           a plot goes where its table goes
pipeline/match.py                           ranked table into its reference's folder
pipeline/build_protein_set.py               five tables into intermediate/protein_set
pipeline/isoform_processing_deltas.py       five tables into intermediate/protein_set
pipeline/enumerate_pool.py                  pool_overlap into intermediate/protein_set
pipeline/mass_fractions.py                  its own dir + the paths it reads back
pipeline/digest.py                          every path through common (was building its own)
pipeline/literature_inventory.py            its own dir
pipeline/comparison.py                      its own dir (unchanged location)
pipeline/excerpt.py                         the literal paths retargeted
tests/conftest.py                           the new globals added to the leak guard
tests/test_standard_outputs_current.py      paths through standard_path
compare_output_trees.py                     NEW — the acceptance check, tooling not a stage
```

`compare_output_trees.py` sits at the repository root and is deleted when Step 7a closes.

**R2 changes one thing.** R1 put this tool in a new `scripts/` folder, as the handoff
specified. "Scripts" names how a file was made, not what it holds — every Python file in the
repository is a script — and `compare_trees.py` left "trees of what?" unanswered. Both fail
the naming rule in `conventions.md`. The tool is now `compare_output_trees.py` at the root: no
new folder meaning for one temporary file, and the name says what it compares. Nothing else in
the delivery changed.

**Hand-delete after extracting R2 (skip if already done):** `scripts/compare_trees.py`, then
the empty `scripts/` folder. (The 7a handoff's two references to `scripts/compare_trees.py` are now stale; they are
corrected with the rest of the docs in delivery 5.)

## The run, in order

Each line is one line; the VS Code terminal takes them one at a time.

```
python run.py protein-set --offline
```
```
python run.py composition --offline
```
```
python run.py mass-fractions --offline
```
```
python run.py standard
```
```
python run.py usda
```
```
python run.py comparison
```
```
python run.py match
```
```
python compare_output_trees.py ../outputs_original outputs
```

Post back the last command's log from `logs/`, plus `tree /F /A outputs > outputs_tree_new.txt`.

## What the comparison should say

Run here against a simulated post-run tree built from your real `outputs_original`:

```
old tree : 111 files
new tree : 109 files
identical body, path unchanged : 28
identical body, moved          : 61
binary, not compared           : 20
BODY DIFFERS                   : 0
MISSING from the new tree      : 0
new files not in the old tree  : 0
expected not-regenerated       : 2
```

The two not regenerated are named in `NOT_REGENERATED` at the top of `compare_output_trees.py` with a
reason each: `match_rate.tsv` (superseded in Step 6) and `match_rate_filtered.xlsx` (yours).
Anything else in BODY DIFFERS or MISSING is a real finding — stop and post it rather than
deleting `outputs_original`.

Binary files (plots) are compared by presence, not content: matplotlib does not write
byte-reproducible PNGs across runs, so a byte comparison would fail for a reason that has
nothing to do with this step. Twenty of the 111 are binary.

## After the comparison passes

Delete `outputs_original/` by hand. Not before — it is the only evidence the move changed
nothing, and no code touches it (D61).

## The resulting tree

```
outputs/
├── flags.tsv
├── intermediate/            what feeds the standard but is not the standard
│   ├── protein_set/         11
│   ├── composition/          7
│   ├── digest/               6
│   ├── literature_inventory/ 3
│   └── mass_fractions/      17
├── standard/                13 deliverable + profile tables at the top
│   ├── plots/               12   the standard's own plots
│   ├── uncertainty/          5 + plots/ 6
│   ├── stress/               5
│   └── sensitivity/          4 + plots/ 2
├── match/                    6
│   ├── skeletal_muscle_protein_with_non_protein_metabolite_pools/ 1
│   ├── skeletal_muscle_protein/                                   1
│   └── gorissen_2018_human_muscle/                                1
├── comparison/               4
└── usda/                     4
```

## How it is built, for review

- **The placement table is data, in one place.** `common.STANDARD_SUBFOLDERS` maps a file name
  to its subfolder; `standard_path(name)` returns its full path, defaulting to the top of
  `standard/`. A file not listed stays at the top — so adding a deliverable needs no entry, and
  moving one is a one-line change. `STANDARD_PLOT_SUBFOLDERS` does the same for plots, which is
  the rule "a plot goes where its table goes" written once.
- **No folder name is typed into the match code.** `match.py` already named the ranked table
  from the `[reference.*]` section; the folder now comes from the same string
  (`f"{r['name']}/match_rate_ranked_{r['name']}.tsv"`). Add a reference to
  `config/match_rate.ini` and its folder appears.
- **The file names are unchanged**, including the ranked tables inside their reference folders.
  Your call, and the right one: a file has to say what it is when it is read on its own.
- **`common.write_text_file(path, text)`** creates the parent folder before writing. Each stage's
  write loop did `OUT_DIR.mkdir()` then wrote a flat name; with subfolders that would fail on the
  first file.
- **`digest.py` was building its own paths from `ROOT`** rather than from `common`. Now routed
  through the constants, which is the handoff's "every path resolved through `common`".
- **`conftest.py`'s leak guard** now covers all 18 path globals, not the original 4.
- **`category_outputs(category)`** in `common.py` returns `outputs/<category>/{intermediate,standard}`
  for Step 7b — so blood's first stage has its folders without typing a path.

## Verified here / not verified here

Verified in the sandbox: all 25 pipeline modules import; `pipeline/`, `tests/` and `run.py`
compile; no output path is built anywhere outside `common.py`; the placement helpers resolve to
the tree above; `compare_output_trees.py` runs against your real 111-file `outputs_original` and
reports 0 differences, 0 missing.

**Not verified here: the test suite.** The sandbox has no network and pytest could not be
installed, so `python run.py test` has not been run against these files. That is the first
thing your run will tell us.

## Two things noticed, neither acted on

1. **`excerpt.py` lists three files the pipeline does not produce** —
   `sensitivity_non_protein_metabolite_pool_turnover_frame.tsv`, `_basis.tsv`, `_sex.tsv`. They
   look like planned 4b sensitivities that were stated rather than computed (the resupply frame
   had no turnover source). Their paths were retargeted with the rest; removing the entries is a
   removal, so it needs your yes. Delivery 3 rebuilds this file per stage anyway — it can go
   there.
2. **`aggregate.py` writes a literal path into `standard_summary.ini`**
   (`"outputs/standard/_calculated_amino_acid_standard.tsv (…)"`). Still correct, because the
   deliverable stayed at the top of `standard/`. Flagged so it is on the list if a later step
   moves that file.


---

## What R3 changed

The R2 run stopped in the test stage with three failures. `protein-set` itself ran clean —
`accessions.ini` (3,788) and `segments.ini` (5,608) were written before the tests ran.

**1. A real defect: `standard_path()` ignored a redirected stage.**
`test_check_mode_is_current_after_a_build` patches `npmp.OUT_DIR` to a temp folder and
`common.REPO_ROOT` with it. R2's `common.standard_path(rel)` resolved against
`common.STANDARD_DIR` instead, so the stage walked past the redirect and wrote into the real
repository — then `relative_to(REPO_ROOT)` raised, which is how it surfaced.

The cause was in the map: R2 stored absolute directories, fixed at import time. A stage pointed
anywhere else could not follow. R3 stores subfolder **names**, and `standard_path(name, base)`
takes the base from the caller — every stage passes its own `OUT_DIR`:

```
STANDARD_SUBFOLDERS = {"uncertainty_intervals.tsv": "uncertainty", ...}
common.standard_path(rel, OUT_DIR)
common.standard_plot_path(name, ext, OUT_DIR)
```

This is worth more than the test it fixes. `outputs/<category>/standard/` is the same problem:

```
blood = common.category_outputs("blood")["standard"]
common.standard_path("uncertainty_intervals.tsv", blood)
  -> outputs/blood/standard/uncertainty/uncertainty_intervals.tsv
```

A category gets the whole placement table by passing its own base. Had this shipped as R2, the
first blood stage in 7b would have written into the muscle tree.

**2 and 3. Two stale assertions in `tests/test_match.py`.** The ranked table's key in the
`files` dict is now its path under `match/`, since the reference folder comes from the same
config section name as the file name. The two tests still looked for the flat key:

```
"match_rate_ranked_new.tsv"        ->  "new/match_rate_ranked_new.tsv"
files["match_rate_ranked_old.tsv"] ->  files["old/match_rate_ranked_old.tsv"]
```

The file names on disk are unchanged. The tests now assert the placement as well as the content,
which is the right thing for them to check.

**Files changed from R2 (7):** `pipeline/common.py`, `aggregate.py`, `uncertainty.py`,
`stress.py`, `non_protein_metabolite_pools.py`, `plots.py`, `tests/test_match.py`.
Everything else in the tarball is byte-identical to R2 — but extract the whole thing, it is the
complete delivery.

**Re-verified here:** all 25 modules import; everything compiles; `standard_path` resolves
correctly against the production base, a redirected base, and a category base; the simulated
tree against your real 111 files still gives 0 body differences and 0 missing. The test suite
still has not run here — no network, no pytest. Your run is the check.
