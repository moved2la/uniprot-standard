# Handoff — Step 6: Match Rate against USDA

**Project:** Sequence-Derived Amino Acid Standard for the Reference Adult Human
**Plan:** `docs/00_project_plan_R11.md` (Step 6)
**Governing rule:** `PROVENANCE.md`
**Depends on:** Step 4 (`outputs/standard/_calculated_amino_acid_standard.tsv`), Step 4b (`_calculated_amino_acid_standard_with_non_protein_metabolite_pools.tsv`, `eaa_subset_with_non_protein_metabolite_pools.tsv`)
**Feeds:** the Army DEVCOM RFP response (pre-EOM); Step 9 (paper); Step 8 (whole-body Match Rate, later)
**Status:** CLOSED 2026-09-18 — deliveries 1, 2, 2b, 3, 4 R2 logged below; narrative in `docs/step6_report.md`; plan R11 ticks the step; next handoff `docs/handoffs/07a_blood_handoff.md`

---

## Goal

Formalise the Match Rate calculation in code against the new standard, run it against the USDA food database in the
free-amino-acid convention, and publish version-labelled results: every food against each available reference, and
the reference foods (whey, pea, egg, steak, the current blend) under the old and new standards side by side.

## What exists

Two muscle references, each with a version label in its header:
- `ref = skeletal muscle protein` — `_calculated_amino_acid_standard.tsv` (D66; protein-only, ten columns).
- `ref = skeletal muscle protein + non-protein metabolite pools (carnosine)` —
  `_calculated_amino_acid_standard_with_non_protein_metabolite_pools.tsv` (D73–D79, D82; the same ten columns with the
  histidine pool folded into `total_<fiber type>_with_non_protein_metabolite_pools` and `standard_with_non_protein_metabolite_pools`).
Both in percent of amino acid mass, free convention (D7), summing to 100; the `standard` column is the fiber-type mix
(D72). The indispensable amino acids per FAO 2013 (D62) are in `eaa_subset.tsv` (protein-only, mg per g protein and
share) and `eaa_subset_with_non_protein_metabolite_pools.tsv` (share, protein-only beside with-pools). Cysteine and methionine are
separate columns (D27).

## Decisions needed before build (author's) — all settled 2026-09-16/17, see the delivery log

1. **Which reference is v1.0** — the with-carnosine muscle standard is the working assumption (plan R9 fork point);
   whole-body follows when Step 7 categories exist. Every output carries the reference's version label.
2. **EAA-only vs all twenty** — working assumption EAA-only (planning session); the nine FAO 2013 headings, with
   SAA (Met + Cys) and AAA (Phe + Tyr) as the report groups them or the nine individually — decide.
3. **The formula** — the current spreadsheet's Match Rate formula is the input, transcribed as it is (D50 pattern)
   before any change is discussed; normalisation and basis (per g protein vs per g amino acid) are decisions.
4. **Surplus above proportion** — counted as surplus, not loss (raised in the 3b thread, "Match Rate Plus"); whether
   v1.0 carries it or leaves it for the delivery layer.
5. **Cysteine** — the old spreadsheet ignored it on the grounds that methionine suffices; the standard keeps both.
   Score them as the SAA group, separately, or drop one — decide (deferred from Step 2, handoff 02).

## Inputs to obtain

- The current NutriMatch spreadsheet (the formula and the current reference foods' scores).
- USDA FoodData Central: the amino acid fields of the foods to score, in the free convention (USDA reports free
  amino acid g per 100 g food; "cystine" maps to cysteine as 2 × cysteine − 2 H per cystine, D27). Fetched or
  hand-obtained and hashed like every other source; the manifest is the record.
- Gorissen et al. 2018 (Amino Acids 50:1685, DOI 10.1007/s00726-018-2640-5) — obtained; on disk at
  `data/literature/gorissen_2018/726_2018_Article_2640.pdf`, transcribed in `config/gorissen_2018_comparison.ini`.
  The comparison is a stage (delivery 2): fourteen rows across fifteen amino acids, both sides renormalised, no verdict;
  histidine 2.66 % protein-only and 3.07 % with the pools against Gorissen's 4.61 %; phenylalanine 4.83 against 6.25
  (`outputs/comparison/calculated_vs_gorissen_2018.tsv`). The numbers that stood here before delivery 2 came from the
  planning session and are superseded.

## Deliverables

- `pipeline/match.py` and a `python run.py match` command (or stage), reading a config that names the reference
  file, the EAA headings, the formula's constants, and the food table; nothing named in code.
- USDA ingestion in `data/usda/`, hashed; the column map transcribed from the file's own headers, cited.
- `outputs/match/match_rate_per_food.tsv` (every food × every available reference, version label per row);
  `outputs/match/reference_foods.tsv` (whey, pea, egg, steak, current blend: old score, new score per reference).
- `docs/methods.md` §Match Rate with the formula written out; `docs/formula.md` extended with the Match Rate
  arithmetic and a worked example; `docs/gorissen_comparison.md`.
- Every published score carries the reference version label (plan R7 §6): "Match Rate v1.0, ref: skeletal muscle
  protein + carnosine, D73–D79".

## Explicitly out of scope

Match Rate Plus (absorption, first-pass, burn — the taxes and tolls); any change to either standard; other tissue
categories (Step 7).

## Delivery log

**Delivery 1 (2026-09-17) — the rename, and the food side.**

*The rename (D82; queued at the 4b close, settled here).* The tier is **non-protein metabolite pools**, defined in
`docs/methods.md` against the other two states (protein-bound, free). The adjusted table is
`_calculated_amino_acid_standard_with_non_protein_metabolite_pools.tsv`; the four computed columns carry the suffix
`_with_non_protein_metabolite_pools`; the six copied contractile / builders columns keep their names. The config file,
the stage and module, rule A10 and the source `role` values take the same term.

Renamed by hand in the file explorer (code renames nothing — D61), before running anything:
`config/bound_metabolite_pools.ini` → `config/non_protein_metabolite_pools.ini` is in the tarball as the new name, so
**delete the old `config/bound_metabolite_pools.ini`**; likewise delete `pipeline/bound_pools.py` and
`tests/test_bound_pools.py`, whose replacements ship under the new names.

Then, after `python run.py standard`, delete these nine superseded files from `outputs/standard/`:
`_calculated_amino_acid_standard_with_bound_pools.tsv`, `bound_pools_summary.ini`,
`bound_pool_adjustment_per_amino_acid.tsv`, `bound_pool_amounts_per_kg_muscle.tsv`,
`sensitivity_bound_pool_turnover_frame.tsv`, `sensitivity_bound_pool_basis.tsv`,
`sensitivity_bound_pool_sex.tsv`, `sensitivity_bound_pool_spread.tsv`, `eaa_subset_with_bound_pools.tsv`.

*The food side (D83).* New stage `pipeline/usda.py` and command `python run.py usda`; hand-written
`config/usda_food_data.ini`; rules U1–U7 in `docs/conventions.md`; `tests/test_usda.py` (14 synthetic tests) and
`tests/test_usda_outputs_current.py`; `data/usda/*.zip` gitignored; methods §"The food tables"; pipeline map and
excerpt spec updated. Outputs in `outputs/usda/`: `amino_acids_per_food.tsv`, `foods_without_amino_acids.tsv`,
`usda_nutrient_map.tsv`, `usda_archive_summary.ini`, plus `data/usda/manifest.ini`.

Run order: put both CSV archives in `data/usda/` → `python run.py usda` → `python run.py standard` (one run, for the
rename) → delete the nine superseded files by hand. Against the April 2026 Foundation archive in the sandbox: 395
foods in membership, 54 with amino acid panels, 341 with no amino acid row.

**Delivery 2 (2026-09-17) — the comparison with Gorissen 2018.** Stage `pipeline/comparison.py`, command
`python run.py comparison`, rules X1–X6, `config/gorissen_2018_comparison.ini` (transcribed from the PDF with page-level
locations, D79), `docs/gorissen_comparison.md`, thirteen tests; D84 (the comparison, and with nothing else) and D85 (the
two printed zeros are not measurements; excluded from both sides; mass balance computed). Outputs in
`outputs/comparison/`. Run on the workstation; all tests passed.

**Delivery 3 (2026-09-17) — Match Rate.** The formula transcribed from `Base_Match_Rate_Formula.xlsx` (D87): both
sides as shares of the scored set, the smallest of (food share / reference share) is the score, its amino acid the
limiting one; the spreadsheet's Steps 8–10b reduce to the same number and are carried as the per-amino-acid ratio
columns (rule M5); protein content never enters (M1). Stage `pipeline/match.py`, command `python run.py match`, rules
M1–M6, hand-written `config/match_rate.ini` (three references: the primary with non-protein metabolite pools, the
protein-only column, and Gorissen 2018's human muscle on its own eight rows), hand-maintained
`config/food_amino_acids_other_sources.csv` (header-only as shipped; columns in `docs/conventions.md`), 19 synthetic
tests including the transcription test (the spreadsheet's four foods reproduce cells G156:J156 to the last digit) and
3 currency tests; D86 (scored set), D87 (formula), D88 (two scripts, split at publication). Outputs in `outputs/match/`.
`docs/formula.md` "Match Rate" with the pea worked example; `docs/methods.md` §Match Rate; pipeline map, README,
excerpt spec. Also in this delivery: the stale pre-D85 wording in `comparison.py`'s docstring and output header fixed;
the essential-row grouping for X4 moved out of code into the config (`essential_rows`, with the paper's location);
three Gorissen locations corrected against the PDF and a `units_note` added (the values are read as free-amino-acid
masses; the paper states no residue conversion); `docs/gorissen_comparison.md` §3 and §5 reworded to report mode and
D85's rationale softened (the mass balance is a bound, not a test — uncorrected hydrolysis losses mean recovery below
100 % is expected under any protein figure). Smoke-run in the sandbox against the real USDA tables with the Gorissen
reference only (the calculated standards are not in the tarball): 5,156 foods, 5,019 scored, 137 not scored (a scored
amino acid unreported), 6 at zero; median 74.7 %; phenylalanine limits 39 % of foods under the old reference,
histidine and lysine 23 % each.

Run order for delivery 3: extract → `python run.py match` (needs `outputs/standard/` and `outputs/usda/` on disk) →
`python run.py excerpt` and upload. Nothing to delete. Ran clean on the workstation.

**Delivery 4 (2026-09-17) — the output layout, after review of delivery 3's tables.** The author's findings: a table
he cannot rebuild in Excel on his own spreadsheet is worth little; the rows did not carry the grams; the headers
carried explanation as well as provenance; several columns repeated one value on every row. Changes, and nothing
else: (1) a sixth output, `match_rate_steps.tsv` — one row per food × reference, the spreadsheet's own walk in its
order and names (rows 12–20, 22–23, 30–37, 100–108, 145–152, 153–156), with each reference's values in the header (its
column A); (2) in `match_rate_per_food.tsv`, `reference_label`, `scored_set`, `scored_amino_acids`, `min_data_points`
and `citation` removed, `scored_sum_g_per_100g` renamed `eaa_g_per_100g` and `eaa_percent_of_protein` added beside
`protein_g_per_100g`; (3) headers are provenance only (standing rule in `docs/conventions.md`, "Ini style").
`match_rate_by_reference.tsv`, the ranked tables, the counts, the not-scored list and the summary keep their names and
columns. Reference ids unchanged. An intermediate cut of this delivery shortened the reference ids and replaced two
tables; the author rejected it as beyond what was asked and it was reverted before this drop. Twenty-two synthetic
tests (the steps table reproduces the sheet's Pea cells I22, I23, I34, I108, I148, I153, I155, I156).

Run order for delivery 4: extract → `python run.py match` (every file overwrites its predecessor; nothing to delete)
→ `python run.py excerpt` and upload. To validate the new reference in the spreadsheet: add a tryptophan row (row 20)
and extend every SUM from 12:19 to 12:20; the nine reference values are in the file header.

## Open (documented 2026-09-18; the author's call is to do nothing on any of them yet)

- **Tryptophan.** Under the new reference tryptophan limits 49.7 % of scored foods and is the one scored amino acid the
  Gorissen comparison cannot check (acid hydrolysis destroys it). The standard's W is 1.54 % of amino acid mass (1.98 g
  per 100 g protein); USDA's meats sit near 1.0–1.1 g per 100 g protein. Three candidate explanations, none separable
  with what is on disk: the sequence-derived W is right and measured muscle W is low; USDA's tryptophan (largely older
  or calculated values) is low; Layer B weights W-rich proteins too heavily. Proposed when taken up: a tryptophan-
  preserving muscle measurement transcribed into the comparison stage with a D-number; no change to the standard. Until
  then the report says W is unverified by measurement and limits half of foods. The author's read (2026-09-18): the
  sensitivity to the one amino acid usual measurement destroys is a finding for the paper in itself.
- **A minimum protein content** for the ranked tables. The score is a proportion, so peaches score 86 % on 0.9 g protein
  and rank above steak. The author agrees a floor is sensible; lean: one hand-written number in `config/match_rate.ini`
  applied to the ranked view only, the per-food, by-reference and steps tables complete, the header saying so. The
  number is the author's.
- **Consolidation of near-identical USDA preparations** (pinned by the author). Sunflower kernels oil-roasted with salt,
  without salt, and dried score 54.5717, 54.5717, 54.5707 %; five rabbit entries sit within a tenth of a point. The
  amino acids survive simple processing, so one food should appear once; the rule for "same food" (a tolerance on the
  scored vector, a name pattern, or a hand list) is a later Match Rate revision with its own D-number.
- **Which archive wins** when a food is in both Foundation and SR Legacy — still two rows (U6, M4). Same food from USDA
  and from the other-sources file is likewise two rows.
- **Zero amino acid values** — scored as published (0 %, limiting amino acid named, M3). Whether a USDA zero is a
  measurement or an absence is a USDA question the stage does not answer.
- **Cystine → cysteine** (config note): open until the FoodData Central documentation says whether USDA's cystine figure
  is already expressed as cysteine equivalent. Nothing in the scored set depends on it.
- **The reference-foods table** (whey, pea isolate, egg, steak, the current blend; old score beside new): whey, egg and
  steak are USDA rows and already in `match_rate_by_reference.tsv`; pea isolate and the blend need rows in
  `config/food_amino_acids_other_sources.csv` with their source.
- **The leucine correction factor** (concentration density; taxes and tolls) — with the blend script (D88).
- **Mingrone 2001's protein assay** — the mass balance's second row is only as independent of the paper's nitrogen ×
  6.25 as that assay is; confirm against the D77 PDF's methods when convenient.
- **Match Rate "v1.0"** — carried from `config/match_rate.ini [meta] version` into every header; the standard itself is
  not versioned before release. Reconcile at the paper step if the two conventions collide.
- **Step close:** done — `docs/step6_report.md`, plan R11, this handoff, `docs/handoffs/07a_blood_handoff.md`.

## Deferred / raised (carried from 4b)

- The resupply-frame sensitivity of the muscle standard needs a muscle-protein turnover range on disk; not blocking.
- Harris 2012 "p. 6" for the sole-dipeptide statement: confirm in the PDF.
- 7b items: fetch retirement (D80), source list out of `mass_fraction_decisions.ini`, per-stage hashing (D81),
  `docs/run_order.md`, README trimmed.
