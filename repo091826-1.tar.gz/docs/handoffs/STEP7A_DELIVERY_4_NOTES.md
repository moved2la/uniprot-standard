# Step 7a — Delivery 4: the bookkeeping

Everything outstanding except the docs. No stage changes what it computes; one header line
changes on purpose.

## Files (21)

```
pipeline/common.py                        outputs paths become functions; hash_ini_sections
pipeline/fetch_literature.py              log + README sorted A-Z; no default for unused_marker
pipeline/non_protein_metabolite_pools.py  hashes the manifest entries it reads, not the file
pipeline/excerpt.py                       one spec per command
pipeline/aggregate.py                     call sites
pipeline/build_protein_set.py             call sites
pipeline/composition.py                   call sites
pipeline/digest.py                        call sites
pipeline/enumerate_pool.py                call sites
pipeline/isoform_processing_deltas.py     call sites
pipeline/literature_inventory.py          call sites
pipeline/mass_fractions.py                call sites
pipeline/plots.py                         call sites
pipeline/ptm_disclosure.py                call sites
pipeline/stress.py                        call sites
pipeline/uncertainty.py                   call sites
tests/conftest.py                         guard lists only the roots that are still globals
tests/test_paths.py                       NEW — 15 tests
tests/test_composition_outputs_current.py call sites
docs/handoffs/STEP7A_DELIVERY_4_NOTES.md
```

Nothing in `config/` or `data/`. No hand-deletes.

## 1. The frozen paths, fixed properly

Delivery 1 made the `outputs/` paths constants; deliveries 1 R2 and 2 R2 each shipped a bug
because a constant computed at import cannot follow a redirected root. The remaining ones were
safe only because no test happened to redirect `OUTPUTS_DIR`.

They are now functions — `intermediate_dir()`, `protein_set_out_dir()`, `composition_dir()`,
`digest_dir()`, `literature_inventory_dir()`, `mass_fractions_dir()`, `standard_dir()`,
`composition_tsv()`, `composition_summary_ini()` — across 51 call sites.

`tests/test_paths.py` is the part that matters: 15 tests that redirect `OUTPUTS_DIR` and
`DATA_DIR` to a temp folder and assert every path follows. Two of these bugs each cost a run and
a revision; this fails the moment a path goes back to being frozen.

It also covers what Step 7b needs:

```
blood = common.category_outputs("blood")
common.standard_path("uncertainty_intervals.tsv", blood["standard"])
  -> outputs/blood/standard/uncertainty/uncertainty_intervals.tsv
```

## 2. Per-stage hashing — the Step 6 case

`non_protein_metabolite_pools` hashed the whole of `data/literature/manifest.ini` into its
header. Adding a source for another category changed that hash, so the header claimed the
stage's inputs had moved when nothing it reads had. That is the exact case pinned in Step 6.

`common.hash_ini_sections(path, sections)` hashes only the named sections, sorted, keys sorted
within them — so the hash depends on what was read, not on file order or how the stage asked.
A named section that is absent hashes as `<absent>` rather than being skipped, so a section
disappearing changes the hash instead of quietly matching.

`green_light()` already knew which manifest sections the stage's sources own; it now returns
them, and the header records:

```
input.manifest = data/literature/manifest.ini sections [file.baguet_2009.file.1, ...] sha256 <h>
```

Demonstrated on a synthetic manifest:

| change | whole-file hash (old) | read-sections hash (new) |
|---|---|---|
| a source added for another category | **moves** — false alarm | does not move |
| a source this stage reads changes | moves | **moves** |

**This changes that one header line on purpose.** Everything below the header is unchanged.

The other manifest readers needed nothing: `mass_fractions` and `comparison` verify individual
file hashes against the manifest (B0) rather than hashing the manifest, and
`literature_inventory` reads every entry by design, so a whole-file hash is correct there.

## 3. Per-stage excerpt specs

`excerpt.py`'s single flat list is now `SPECS`, a dict keyed by command in run order, and
`SPEC` is the concatenation the runner walks. Adding an output means adding its cut beside its
command instead of hunting through one list.

All 79 entries preserved and verified against the original — identical cuts, identical paths
apart from the `outputs/` retargeting from delivery 1:

```
fetch-literature  1     standard    29
protein-set      10     usda         4
composition       4     comparison   4
mass-fractions   19     match        8
```

## 4. Sorting and the marker default

- The hashing loop logs A-Z, and `data/literature/README.md` lists sources A-Z — same order as
  `manifest_map.tsv` and the folder listing. All four now read together.
- `unused_marker` no longer has a code default. Config says what the word is or the stage stops:
  the word printed for a source that feeds no calculation is a decision, not a fallback.

## 5. The placeholder rule

`___` means the author fills this in; an unknown hash is blank.
`test_no_placeholder_hash_anywhere_in_config` (delivery 2) walks every `.ini` under `config/`
and fails on a `___` in any `sha256` key. The convention itself goes into `conventions.md` with
the rest of the docs in delivery 5.

## What to run

```
python run.py test
```

Then, because the header line changes:

```
python run.py standard
```

`_calculated_amino_acid_standard_with_non_protein_metabolite_pools.tsv` and its companions get
the new `input.manifest` line. Everything below the header should be identical — worth a diff on
one of them before committing.

Nothing else needs rerunning.

## Verified here

32 tests driven directly (17 literature, 15 paths); all 25 modules import; everything compiles;
the excerpt split verified entry by entry against the original; the manifest-hashing behaviour
demonstrated on a synthetic manifest as tabulated above. pytest still will not install in the
sandbox, so `python run.py test` on your machine remains the real check.

## Left for delivery 5 (docs)

`docs/run_order.md`, `pipeline_map.md`, `conventions.md` (Folder meanings, A0 as amended, the
placeholder rule, the retired fetch rules), the README trim, `decisions.md` D90+, the Step 7b
handoff check, plan R14, `docs/step7a_report.md`.
