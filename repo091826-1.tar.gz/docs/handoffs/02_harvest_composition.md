# Handoff — Step 2: Harvest and Composition Engine

**Project:** Sequence-Derived Amino Acid Standard for Human Skeletal Muscle
**Plan:** `docs/00_project_plan.md`
**Depends on:** Step 1 (`config/accessions.ini`, `config/segments.ini`)
**Feeds:** Step 3 (needs molecular weights for iBAQ→mass), Step 4 (needs composition vectors)
**Status:** Code delivered 2026-09-11; awaiting the workstation run. See "Execution record" below — it supersedes Tasks A–F where they differ.

---

## Execution record (2026-09-11)

### Decisions taken before build (all logged: D25–D30)

| # | Question | Decision |
|---|---|---|
| — | File naming | `data/uniprot_verification.ini` → `data/uniprot_sequences.ini`; `verify_accessions.py` → `fetch_sequences.py` (D25). |
| 1 | Mass source | PubChem PUG REST by compound name. The letter→name table is *parsed by code* from the IUBMB web copy of IUPAC-IUB JCBN 1983 Table 1 at every fetch; the only author-written content is `config/composition_decisions.ini` — the table URL, the PubChem endpoint, the `L-` prefix rule, and the two extra compound names (D26). Anthony rejected a transcribed seed ("everything by code unless absolutely necessary"). PubChem serves `MolecularWeight` to two decimals — disclosed in the table header and methods. |
| 2 | Cysteine | Reported as cysteine at free-cysteine mass; Cys and Met separate columns; USDA "cystine" mapping is a Step 6 ingestion issue (D27). |
| 3 | PTMs / 3-methylhistidine | Not modelled; mass disclosed per entry from UniProt PTM-class features + `ptmlist.txt` `MA` (D28). Processing mass disclosed per entry from `segments.ini`. Both to full precision. |
| 4 | Row shape | One row per accession per segment set; tier as list; TSV; fractions only (D29). |
| 5 | Hydrolysis-sensitive residues | Full sequence value (D30). |

### What was built

| File | Role |
|---|---|
| `config/composition_decisions.ini` | hand-written: two URLs and one rule, D-numbered |
| `pipeline/fetch_amino_acid_masses.py` | network: parse IUPAC table → `data/iupac/amino_acid_symbols.ini` → PubChem → `data/pubchem/amino_acid_masses.ini` |
| `pipeline/fetch_ptmlist.py` | network: `ptmlist.txt` → `data/uniprot_ptmlist/` |
| `pipeline/composition.py` | offline: `outputs/composition/amino_acid_composition_per_protein.tsv`, `processing_mass_deltas.tsv`, `processing_mass_bound.tsv`, `composition_summary.ini`; `--check` = currency |
| `pipeline/ptm_disclosure.py` | offline, needs `data/uniprot_raw/`: `ptm_sites.tsv`, `ptm_mass_deltas.tsv`, `ptm_summary.ini` |
| `run.py composition` | fetch masses → fetch ptmlist → composition → ptm_disclosure → tests; `--offline` skips the two fetches |
| `tests/test_masses.py`, `test_composition.py`, `test_ptm_disclosure.py` | offline, synthetic fixtures |
| `tests/test_composition_outputs_current.py` | skipped until the stages have run; then: mass table generated and self-consistent, outputs current, every accession twice, fractions sum to 1 |
| `docs/conventions.md` (rules C1–C3, folders, command), `docs/decisions.md` (D26–D30), `docs/methods.md` "Composition (Layer A)" with ⟨placeholders⟩ | docs |

Differences from Tasks A–F below: no `fetch.py` (harvest done in Step 1); no `config/aa_masses.ini` (the fetched table lives in `data/pubchem/`, since it is what a database said); no per-accession CSVs; `--check` is the currency check, and the master-vs-metabolic table is always written. Sandbox verification: 28 offline tests pass; a dry run of both offline stages on the real 303 sequences with a *synthetic* mass table produced 606 rows, exact water identity, and 92 processed entries (matches Step 1).

### Run 1 (2026-09-11 23:55 UTC) and the patch that followed

Run 1 completed all four stages and 55 tests. Records: masses fetched (20 letters all resolved with the `L-` prefix — PubChem resolves "L-Glycine" to glycine CID 750; water 18.015, H₂ 2.016), `ptmlist.txt` release 2026_03 (750 records, 572 with MA), 606 composition rows, water identity ≤ 2.3 × 10⁻¹⁰ g/mol, 92 processed entries, 2742 PTM sites. Two defects found in review, patched 2026-09-12: (1) generated headers used Windows path separators and swallowed a comment into `served_decimals`; (2) 119 sites went `no_vocabulary_match` because the vocabulary's cross-link identifiers use `...` as a wildcard (`(interchain with G-...)`) and the lookup was exact-only. Wildcard matching, qualifier handling, `match_rule` and `correction_formula` columns added; re-pricing the recorded sites brings unmatched to 0. Run 2 is the full command again (not `--offline`, so the masses header is regenerated too).

### Workstation run (one line each, from the repo root)

```
python run.py composition
```

Expect four stages then tests. If `fetch_amino_acid_masses` stops on the IUPAC table parse, the log says how many letters it found and which are missing — the page changed shape; that is a flag, not a config edit. If `fetch_ptmlist` stops, the log gives the record counts it parsed; the file format is asserted, not assumed. Upload back: `data/iupac/` (page, source.ini, amino_acid_symbols.ini), `data/pubchem/`, `data/uniprot_ptmlist/`, `outputs/composition/`, `logs/` (the new logs).

### Manual acceptance item (needs a browser)

ExPASy ProtParam cross-check of the molecular weight: paste the master-molecule sequence of one entry (slice it from `data/uniprot_sequences.ini` by the `segments.ini` range, or use an unprocessed entry whose whole sequence is the master) into `https://web.expasy.org/protparam/`, and record the ProtParam average MW, the entry, and the date in methods next to our `mw` for the same row. Agreement to the mass-table precision is the expected result; a larger gap is a flag.

### Deferred / raised (filled during the thread)

- **Match Rate and cysteine (→ Step 6).** The current spreadsheet ignores cysteine on the grounds that methionine is "enough" on a mass-fraction basis. Anthony suspects a weakness. To be tested in Step 6 against a cited scoring pattern; the standard carries Cys and Met separately so any treatment is possible (D27).
- **Cysteine ↔ cystine unit mapping when USDA is ingested (→ Step 6).** Cystine = 2 × cysteine − 2 H per molecule (D27).
- **3-methylhistidine as dietary histidine — the argument and its citation (→ paper step).** The code only discloses the mass (D28). Elzinga et al. 1973 (already on the 3a source list) is the candidate citation for actin's methylated histidine.
- **Mass-table precision.** Two served decimals from PubChem. If a later step needs more, the formula × atomic-weight route (also fetchable from PubChem) is the upgrade; not needed now.
- **`uniprot_raw/` is not shipped in tarballs** (large). `ptm_disclosure.py` runs where the JSON is; only its outputs travel.

---


---

## Goal

Two modules and one data file. `fetch.py` pulls every accession in `accessions.ini` from UniProt REST, verifies the sequence against UniProt's published checksum, captures the feature table, and writes `data/sequences.ini`. `composition.py` reads `sequences.ini` and `segments.ini` and produces, for each protein, the residue count vector (ground truth), the residue-mass vector, the free-amino-acid-mass vector, and the molecular weight — for both the master-molecule and metabolic segment sets. When this step is done, Layer A is complete: every number is either a sequence character count or derived from one by arithmetic against a cited mass table. No biology is decided in this step.

## Context you need

- Layer A is exact (D2). This step must not introduce any estimated quantity. The only external constants are amino acid masses, and those come from a cited table in config, not from code.
- Residue counts are ground truth; both mass conventions are derived (D7). The free-AA convention is what USDA and lab AAA use and what Match Rate will consume.
- The collagen pipeline already has a working fetcher (`fetch_sequences.py`, UniProt REST + MD5 + feature JSON → `.ini`) and a reader for segment flags. Generalize; don't rewrite from scratch.
- The working sandbox may have no network. Development and tests run against fixture sequences in `tests/fixtures/`. The live harvest runs on a machine with network and the resulting `sequences.ini` is committed.

## Decisions already made — do not reopen

- D2, D7, D8, D11.
- Step 1 decisions on isoforms and segment flags: read them from `accessions.ini` / `segments.ini` and `docs/decisions.md`. Do not second-guess an isoform choice here; if a fetch reveals a problem (e.g., isoform ID doesn't resolve), log it in "Deferred / raised" and use what resolves, flagged.

## Inputs

- `config/accessions.ini` — every section has `accession`, `isoform`, `seq_version`, `length`, `tier`, `fiber_type`.
- `config/segments.ini` — one or more `[ACCESSION.segment]` sections per accession with `start`, `end`, `in_master_molecule`.
- Collagen pipeline `fetch_sequences.py` and `collagen_stoich_model_v2.py` (project history) — reference implementations.

### Inputs from Step 1 (fill in at Step 1 close)

- Final accession count, Tier 1: 242. Tier 2: 87. Both: 26. Unique: 303.
- Accessions using a non-canonical isoform ID: **none** — rule R1 (D16) fixes the canonical sequence for every entry.
- `segments.ini` runs with `in_master_molecule = false`: 93 (91 N-terminal, 2 C-terminal) across 92 entries. Master runs: 303 (295 from a single Chain feature, 1 whole-sequence, 7 from the union of several Chain features, D24).
- Anything Step 1 flagged for Step 2: nothing open. Two isoform FASTAs 404'd; irrelevant under R1.

### Changes implied by Step 1

- **The harvest is already done.** `data/uniprot_sequences.ini` contains every canonical sequence, MD5-verified against UniProt's published checksum, with UniProt release and fetch time in its header, plus the captured feature table. Task A (`fetch.py`) reduces to: reuse `pipeline/fetch_sequences.py`; do not write a second fetcher. The `sequences.ini` schema below is superseded by `uniprot_sequences.ini`.
- **Isoform handling in Task A is moot.** No `ACCESSION-N` identifiers exist in this set.
- **Fiber type is not a column.** `accessions.ini` has no `fiber_type` field (D17); drop it from the `all.csv` schema in Task D.
- **Tier is a list.** 26 entries carry `tier = 1;2`. `all.csv` should emit one row per (accession, tier) or keep the list; decide and record.
- **Provenance.** `PROVENANCE.md` governs this step too. The amino acid mass table (Task C) must be fetched from a cited source by code or transcribed with a citation per row and a recorded retrieval date — never typed from recollection. The 3-methylhistidine and cysteine notes in the open questions require citations before they enter `methods.md`.

## Tasks

### A. `src/muscle_aa/fetch.py`

1. Read `config/accessions.ini`. For each entry build the UniProt identifier: `ACCESSION` for canonical, `ACCESSION-N` for a specific isoform.
2. Fetch from `rest.uniprot.org`:
   - Sequence: `/uniprotkb/{id}.fasta` (isoform IDs resolve here).
   - Entry JSON: `/uniprotkb/{accession}.json` — capture `sequence.md5Checksum`, `sequence.length`, `entryAudit.sequenceVersion`, `entryAudit.lastSequenceUpdateDate`, and the `features` array (Initiator methionine, Propeptide, Signal, Chain, Region, Modified residue).
   - Note: the JSON checksum is for the canonical sequence. For isoforms, compute MD5 of the fetched FASTA and record it; cross-check length against the isoform length in the JSON `comments` (ALTERNATIVE PRODUCTS) block.
3. Verify: computed MD5 of the fetched sequence == UniProt's published MD5 (canonical) or recorded isoform length matches (isoform). Verify `length` and `seq_version` match `accessions.ini`. **Any mismatch is a hard failure** — print what differed and exit non-zero. A stale `accessions.ini` is a Step 1 correction, not something the fetcher silently tolerates.
4. Write `data/sequences.ini` (schema below). Include a header with the fetch timestamp and the UniProt release (from the `X-UniProt-Release` response header if present).
5. Retries with backoff; polite rate (UniProt asks for reasonable request rates); `--only ACC` and `--dry-run` flags.
6. Non-standard letters (`B`, `Z`, `X`, `U`, `O`) in a fetched sequence: fail loudly. None are expected in these entries.

### B. `data/sequences.ini` schema

```ini
# Generated by fetch.py — DO NOT EDIT BY HAND
# fetched      = 2026-09-XXTHH:MM:SSZ
# uniprot_release = 2026_0X
# source       = https://rest.uniprot.org/uniprotkb/

[P12883]
gene              = MYH7
isoform_id        = P12883            ; or P12883-2 etc.
sequence          = MGDSEMAVFGAAAPYLRKSEKERLEAQ...
length            = 1935
seq_version       = 5
md5_uniprot       = <from JSON>
md5_computed      = <computed>
md5_match         = true
last_seq_update   = 2003-XX-XX
feature.initiator_methionine = 1-1
feature.chain                = 2-1935 ; Myosin-7
feature.region.0             = ...    ; as many as UniProt lists, description after ';'
```

Features are captured verbatim for audit. `composition.py` does **not** read features — it reads `segments.ini`, which Step 1 wrote by hand from those same features. The feature capture exists so a reviewer can check `segments.ini` against the source without leaving the repo.

### C. `config/aa_masses.ini`

The one biological constant table in Layer A. Average (not monoisotopic) masses, since composition is a bulk-mass quantity.

```ini
# Free amino acid average molecular masses, g/mol.
# source   = <cited — e.g., IUPAC / NIST WebBook / PubChem CID per amino acid>
# retrieved = 2026-09-XX
# residue_mass = free_mass - water ; water = 18.01528 (cite)
[G]
name      = Glycine
free_mass = 75.0666
cid       = 750
...
```

Twenty entries. Every value sourced. Record the water mass and its source. Do not type these from memory — pull each from the cited source in-thread.

### D. `src/muscle_aa/composition.py`

For each accession, for each segment set (`master` = segments with `in_master_molecule = true`; `metabolic` = all segments):

1. Concatenate the flagged segments' residues (slice the sequence string by `start`/`end`, 1-indexed inclusive — same convention as the collagen pipeline).
2. **Residue count vector** — `Counter` over the 20 letters. This is the stored ground truth.
3. **Residue-mass vector** — `count[aa] × residue_mass[aa]`. Sum + one water = protein MW.
4. **Free-AA-mass vector** — `count[aa] × free_mass[aa]`. Sum = MW + (n − 1) × water, where n = residue count. Use this identity as a unit test.
5. **Fractions** — each vector normalized to sum 1, in both conventions. Report as fraction and as g/100 g.
6. **Molecular weight** — from the residue-mass sum. Step 3 needs this for iBAQ→mass.
7. Output: `outputs/composition/<accession>_<master|metabolic>.csv` plus one combined table `outputs/composition/all.csv` with columns `accession, gene, tier, fiber_type, segment_set, n_residues, mw, <20 count columns>, <20 residue_frac columns>, <20 free_frac columns>`.
8. A `--check` mode that prints, per protein, the master vs metabolic difference in each fraction. For muscle proteins this should be tiny; print it anyway so the negligibility claim in the paper is a printed number, not an assertion.

### E. Tests (`tests/`)

- `test_masses.py` — 20 entries present; residue = free − water for every row; sums behave.
- `test_composition.py` — against fixtures:
  - A hand-computable synthetic sequence (e.g., `GGGAAAK`) with expected counts, MW, both vectors.
  - One real small protein (e.g., TNNC2 or MYL2 fixture) with MW cross-checked against ExPASy ProtParam for the same sequence. Record the ProtParam value and date in the test docstring.
  - The `(n − 1) × water` identity for every fixture.
  - Segment slicing: a fixture with a false-flagged N-terminal segment; master count = metabolic count − segment length.
- `test_fetch.py` — parses a saved FASTA and JSON fixture; MD5 verification passes; an altered fixture fails.
- No test touches the network.

### F. Documentation

- `docs/methods.md` — section "Sequence acquisition and composition calculation": endpoints, verification, mass table source, the two conventions with the water identity written out, 3-methylhistidine treatment (below).
- `docs/decisions.md` — append.

## Deliverables

- `src/muscle_aa/fetch.py`
- `src/muscle_aa/composition.py`
- `config/aa_masses.ini` (cited)
- `data/sequences.ini` (committed after a live run; MD5-verified)
- `outputs/composition/*.csv`
- `tests/fixtures/`, `tests/test_*.py`
- `docs/methods.md` section, `docs/decisions.md` appended

## Acceptance criteria

- [ ] `fetch.py` runs against every entry in `accessions.ini` and exits zero only when every MD5/length/version check passes.
- [ ] `data/sequences.ini` is committed, with fetch timestamp and UniProt release in the header.
- [ ] `aa_masses.ini` has 20 sourced entries and a sourced water mass; no value came from memory.
- [ ] `composition.py` produces both vectors, both segment sets, for every accession, and the water identity holds for every one.
- [ ] MW for at least one protein matches ExPASy ProtParam for the identical sequence (record the value).
- [ ] `--check` output committed showing master vs metabolic deltas.
- [ ] All tests pass offline.
- [ ] No mass fractions, tier weights, fiber-type mixes, or aggregated profiles appear anywhere in this step's outputs. Per-protein only.

## Open questions this step must resolve

1. **Mass table source.** One authoritative source for all 20 free masses (preferred) vs. per-CID from PubChem. Decide, cite, record.
2. **Cysteine in the free-AA convention.** Lab AAA typically reports cysteine as cysteine or cystine depending on method; USDA reports "cystine". For the standard, report as cysteine (free mass) and note the convention. Confirm and document — this becomes a Step 6 mapping issue when USDA columns are ingested.
3. **3-methylhistidine.** Actin and myosin heavy chain each carry one post-translationally methylated His. Count as His: dietary His is the precursor and the mass difference is negligible. Confirm and write one sentence in methods.
4. **Isoform checksum.** UniProt's JSON gives an MD5 only for the canonical sequence. Decide how isoform sequences are verified (length + spot-check against the isoform's FASTA header, plus stored computed MD5 for reproducibility) and document.
5. **Tryptophan and other hydrolysis-sensitive residues** — nothing to decide here (the sequence is exact), but note in methods that these are reported at full value, which is where the lab comparison in Step 5 will diverge.

## Explicitly out of scope

- Mass fractions, iBAQ, abundance — Step 3.
- Any aggregation across proteins, fiber types, or muscles — Step 4.
- Plots — Step 4.
- Hydroxylation, glycosylation, or any PTM mass adjustment — not relevant for muscle proteins; collagen tier handles its own.
- USDA ingestion, Match Rate — Step 6.
- Adding or removing proteins from the list — Step 1 correction; log and go back.

## Deferred / raised

_(fill in during the thread)_

## Handoff to Step 3

_(fill in at completion — path to `all.csv`, the MW column Step 3 should use for iBAQ×MW, any accession whose fetched length differed from Step 1's record and how it was resolved)_
