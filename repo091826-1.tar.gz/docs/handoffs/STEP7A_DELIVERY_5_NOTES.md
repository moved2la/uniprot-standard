# Step 7a — Delivery 5: docs and close

Documents only. No code, no config, nothing to rerun.

## Files (9) — R2

**R2 replaces the paste-and-delete append file with a complete `decisions.md`.** R1 shipped
D90-D94 as a separate file to be pasted in by hand, out of caution about overwriting a record
I could not verify. Checking was the right move instead — and checking turned up a gap.

```
docs/run_order.md                  NEW — one screen: what to rerun after an edit
docs/step7a_report.md              NEW — the step narrative
docs/00_project_plan_R14.md        NEW — R13 stays; Step 7a done, 7b next
docs/handoffs/07b_blood_handoff.md rewritten against the tree as built
docs/decisions.md                  complete: D1-D94, including D89 which was never logged
docs/pipeline_map.md               every path updated; the tree as built pasted in
docs/conventions.md                Folder meanings, Paths in code, Placeholders, One command,
                                   literature rules (F3/F4/F4b/F6 out, F8/F9 in), A0 amended
README.md                          trimmed 45 -> 43 lines: install, the eight commands, pointers
docs/handoffs/STEP7A_DELIVERY_5_NOTES.md
```

## What to do

1. Extract.
2. `python run.py test` — documents change nothing, so this is a formality, but
   `pipeline_map.md`'s paths are walked by a test.
3. Commit.

Nothing to paste; nothing to delete.

## D89 was missing

**`docs/decisions.md` had no D89.** The R12 plan's §8 says "New in R12 (to be logged in
`docs/decisions.md`): **D89**" — the reorganization becoming its own step before blood, and the
step letters renumbering. It was written in the plan and never made it into the log, so the
record jumped D88 → D90 with the decision that created this whole step absent from it.

The D89 row uses the plan's own §8 wording rather than anything composed now. Two details worth
your eye: it says the source list gains "a per-source line naming what uses it", which was named
`used_for` at build time (D93, noted in the row), and it keeps D71's original step letters as
logged rather than renumbering history.

Verified after assembly: 94 rows, D1 through D94, no gaps, no duplicates, every row four columns.

**`docs/00_project_plan_R13.md` stays.** R14 is the new revision; R13 is history, per the
increment rule.

## The two things in here worth actually reading

**`docs/run_order.md`.** The eight commands with what each reads and writes, and a table of what
to rerun after any edit. It exists because you found the `standard` → `comparison` → `match`
chain from a failing currency test rather than from a document. It also records what does *not*
force a rerun, which is now a real category: re-hashing unchanged literature, and a source added
for another category.

**`docs/step7a_report.md`.** In particular the method lessons — three bugs in this step were the
same bug, a value that looks like an input but is not. And the open items, which are real:
`comparison` has no `--check` currency test, so unlike `match` it would have gone stale
silently; `excerpt.py` names three files the pipeline never writes and warns about them every
run.

## The Step 7b handoff

Rewritten against the tree as built rather than the tree as planned. The part that matters is
that blood needs nothing invented: `config/blood/` exists, `common.category_outputs("blood")`
gives it `intermediate/` and `standard/`, passing that as `base` to `standard_path()` gives it
the whole placement table under its own root, and adding `blood` to `[categories] columns` makes
it a column of the literature map. What blood does need is six scope decisions made before any
code — what blood is, the boundary with liver, tier structure and naming, which hemoglobins, a
metabolite pool or not, and the subtype mix — and sources, of which none are on disk.

It also flags where the first friction is expected: `common.TIER_NAMES` and `aggregate` hard-code
`contractile` / `builders`. Blood's tiers are different words. **That friction is 7c's input —
note it, do not fix it.**

## What Step 7a did not do, on purpose

The older stages still write rule prose into their headers. Bringing `protein-set`,
`composition`, `mass-fractions`, `aggregate`, `uncertainty` and `stress` to provenance-only
headers changes headers deliberately, and Step 7c templates header rendering anyway — doing it
now means doing it twice. Moved to 7c and recorded in plan R14.

## Step 7a is closed after this

`compare_output_trees.py` can be deleted from the repository root — it was tooling for this step
and its job is done. Your call whether to keep it around until blood's first build; it is small
and it would work unchanged on `outputs/blood/`.
