# Step 7a — Delivery 3 R4: the manifest map's columns

**R4 sorts the map A-Z, corrects `mingrone_2001`, fixes the key alignment, and renames the
config key `used_by` to `used_for`.** No other change; R1 of this delivery was
never run. `used_by` read as "which consumer reads this", which was right when the columns were
going to be tissue categories. They are not: `original` is a reference, `non_protein_metabolites`
is a tier, `skeletal_muscle` is a category. Those are purposes. The value `unused` stays as is.

**Scope:** `used_for` per source, the column set, and the `unused` marker. One column of all-X
said nothing; this is the map doing what it was for.

## Files (4)

```
config/literature_sources.ini    22 used_by keys renamed used_for, 12 values changed; new [categories]
pipeline/fetch_literature.py     columns come from config; the unused marker
tests/test_fetch_literature.py   17 tests (was 13)
docs/handoffs/STEP7A_DELIVERY_3_NOTES.md
```

**On shipping the config file.** It carries the three hashes your run recorded
(`harris_1998`, `baguet_2009`, `mingrone_2001`) byte-identical to your copy — checked by
diffing against a reconstruction of your current file, not assumed. The only differences are
the 12 `used_for` lines and the new `[categories]` section. If you would still rather edit in
place, the changes are listed at the bottom.

## What to run

```
python run.py fetch-literature
```

Regenerates `manifest_map.tsv`, `manifest.ini` and `README.md`. Then commit. Nothing else
changes — no stage reads `used_for`.

## The map this produces

```
source                 original  skeletal_muscle  non_protein_metabolites  other
baguet_2009                                       X
carroll_2004                     X
contaminants_maxquant            X
cox_2014                         X
deshmukh_2021                    X
fao_2013               X         X                X
gorissen_2018          X
harris_1998                                       X
harris_2012                                       X
icrp_2002                                                                  unused
johnson_1973                                                               unused
mingrone_2001                                     X
momenzadeh_2023                  X
moreno-justicia_2025             X
murgia_2017                      X
murgia_2021                      X
schwanhausser_2011               X
smith_2011                                                                 unused
tallon_2007                                       X
vega_2022                                                                  unused
wisniewski_2017                  X
yamaguchi_2021                                    X
```

## How each source was placed

Every assignment came from the `role` you had already written in config, with its D-number —
not from any reading of the papers. Three were settled by tracing what actually reads the file:

- **`mingrone_2001` is non-protein metabolites only.** `non_protein_metabolite_pools.ini` takes
  its protein and water per kg (D77). It is also read by the comparison stage —
  `gorissen_2018_comparison.ini` line 130 lists it in
  `compare_against = gorissen_nitrogen_derived, mingrone_2001_measured`, computed at
  `comparison.py:296` — but that is the mass balance, a cross-check inside that stage, not the
  original Match Rate reference. Only `gorissen_2018` is `original`. (Author's correction: being
  read by `comparison.py` is not the same as being part of the baseline.)
- **`fao_2013`** is read by `match_rate.ini` and `match.py` (the scored set) and by
  `aggregate.py` (which writes `eaa_subset.tsv` for the muscle standard). Marked across all
  three on your call — foundational.
- **`icrp_2002` is read by nothing.** It appears only as a source section; no stage, no config
  consumes it. Marked `unused` on your call. It is the Layer C reference-body document pinned
  for Step 8 (D67), and it earns a column when Step 8 exists.

`johnson_1973` (`paper_citation`), `vega_2022` (`not_used`, gated) and `smith_2011`
(`not_pursued`) are cited in prose and feed no calculation, so they carry the marker too.

## How the columns work

`[categories]` in `config/literature_sources.ini`:

```
columns         = original, skeletal_muscle, non_protein_metabolites, other
unused_marker   = unused
```

- The columns and their **order come from config**, not from the data. First-appearance order
  would have put `skeletal_muscle` first because `murgia_2021` is first in the file; this keeps
  the layout you asked for.
- **Blood in 7b is one line**: append `blood` to `columns`, put it in the `used_for` of the
  sources it cites. No code change.
- A `used_for` naming a column that is not in `columns` is a **flag**, so a typo cannot quietly
  drop a source out of the map.
- **Rows are sorted A-Z by source id**, not left in config order: the map is read beside the
  `data/literature/` folder listing, which the explorer sorts A-Z.
- `other` is the column the marker goes in. A source whose `used_for` is `unused` gets the word
  `unused` there — a row of four blanks reads as an unfilled line, the word reads as a decision.
  Today `other` holds those four entries and nothing else.

## Verified here

16 literature tests pass (three new: config-ordered columns, the unused marker, an unknown
column flagged); all 25 modules import; everything compiles; the real config renders the table
above with no unknown-column flags and no source left blank. The suite under pytest is still
your check — the sandbox has no network and pytest will not install.

## If you would rather hand-edit instead of taking the config file

Add after `[meta]`:

```
[categories]
columns         = original, skeletal_muscle, non_protein_metabolites, other
unused_marker   = unused
```

Then rename every `used_by` key to `used_for`, and set these twelve values; the other ten
stay `skeletal_muscle`:

```
johnson_1973    = unused
fao_2013        = original, skeletal_muscle, non_protein_metabolites
harris_1998     = non_protein_metabolites
tallon_2007     = non_protein_metabolites
harris_2012     = non_protein_metabolites
vega_2022       = unused
baguet_2009     = non_protein_metabolites
yamaguchi_2021  = non_protein_metabolites
icrp_2002       = unused
mingrone_2001   = non_protein_metabolites
smith_2011      = unused
gorissen_2018   = original
```
