# Step 6 — delivery 4 R2: the output layout

**R2 replaces delivery 4 R1.** R1 (issued and withdrawn the same day) shortened the reference ids and replaced two
tables; it was rejected as beyond what was asked and is superseded in full. If R1 was run, delete the four files it
wrote under its own names (item 1) before running R2. R2 was first re-issued under R1's file name — wrong, and the
reason this is now labelled R2.

**Date:** 2026-09-17 (R2 2026-09-18) · **Decisions:** none new · **Contents:** 11 files, all changes to delivery 3. Nothing renamed.

## 1. What to do

1. If R1 was run, delete its four orphans from `outputs/match/`: `match_rate.tsv`, `match_rate_ranked_muscle_with_pools.tsv`,
   `match_rate_ranked_muscle_protein_only.tsv`, `match_rate_ranked_gorissen_2018.tsv`. Then extract over the repo root;
   every file in this drop overwrites its predecessor by name.
2. `python run.py match` → 22 synthetic tests, 3 currency tests.
3. `python run.py excerpt` and upload.

## 2. What changed, and only this

- **`match_rate_per_food.tsv`** — columns removed: `reference_label`, `scored_set`, `scored_amino_acids`,
  `min_data_points`, `citation`. `scored_sum_g_per_100g` is now `eaa_g_per_100g`; `eaa_percent_of_protein` added
  beside `protein_g_per_100g`. `reference` and the `ratio_*` columns stay as they were.
- **`match_rate_by_reference.tsv`** — unchanged name and columns.
- **`match_rate_steps.tsv`** — the sixth output, new. One row per food × reference, filter on `reference`. Your
  sheet's walk in your order and names: grams (rows 12–20) · `eaa_g_per_100g` (22) · `reference_eaa_total` (A22) ·
  `percent_of_reference_total` (23) · `step3_scaled_*` (30–37) · `step7_percent_of_reference_*` (100–107) ·
  `step7_min` (108) · `limiting_amino_acid` · `step10b_*` (145–152) · `step10b_total_need_to_consume` (153) ·
  `percent_wasted` (155) · `percent_utilized` (156) · `match_rate_percent`. Steps 8–9 are not written (they cancel;
  the sheet computes them from the Step 3 values). A zero score leaves Step 10b blank, as the sheet would (#DIV/0!).
- **Headers** on every file are provenance only: generated, version, hashes, and one `reference.<id>` line per
  reference carrying its label, source column, scored set and **its values** — your column A. Explanation moved to
  the docs; the standing rule is in `conventions.md` under "Ini style".
- Ranked, counts, not-scored and summary: unchanged names and columns. Reference ids unchanged.

## 3. Validating in your spreadsheet

- **Old reference:** the sheet as it is. Take a `match_rate_steps.tsv` row with `reference = gorissen_2018_human_muscle`,
  paste its eight grams into G12:G19 in the sheet's row order (H I L K M F T V); G156 = `percent_utilized`,
  G153 = `step10b_total_need_to_consume`, G100:G107 = `step7_percent_of_reference_*`.
- **New reference:** add a tryptophan row 20, extend every SUM from 12:19 to 12:20, put the nine values from the
  `reference.skeletal_muscle_protein_with_non_protein_metabolite_pools` header line into A12:A20 (percent of amino
  acid mass; the unit cancels), and validate against that reference's rows.
- The tests do the same on the sheet's four foods and on Pea's cells I22, I23, I34, I108, I148, I153, I155, I156.
