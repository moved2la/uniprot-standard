# Handoff — Step 4: Aggregation and Uncertainty

**Project:** Sequence-Derived Amino Acid Standard for Human Skeletal Muscle
**Plan:** `docs/handoffs/00_project_plan_R5.md`
**Governing rule:** `PROVENANCE.md`
**Depends on:** Step 2 (`outputs/composition/amino_acid_composition_per_protein.tsv`), Step 3b (`config/mass_fractions/{I,IIa,IIx}.ini` and its one-table form `config/mass_fractions_per_entry.tsv`, `outputs/mass_fractions/*`)
**Feeds:** Step 5 (validation), Step 6 (Match Rate)
**Status:** drafted 2026-09-13 at Step 3b close; **interim delivery 1 (2026-09-13, patched)** — the weights also written as one generated table (D61; the `.ini` files kept, combined weights added to them, nothing deleted — the first delivery had the stage delete the `.ini` files, which was wrong and is reverted; no stage deletes a file), FAO 2013 pinned as a source (D62), `config/aggregation_decisions.ini` skeleton for the author's transcription, `python run.py excerpt` tooling. Decisions taken in the Step 4 thread before build are in §"Decided before build" below.

---

## Goal

The standard itself: the amino acid profile of human skeletal muscle protein, per fiber type, in
both mass conventions, with its uncertainty — computed by `pipeline/aggregate.py` from the
per-protein compositions (Layer A) and the per-protein weights (Layer B), and nothing else.

## What exists

- Layer A: `outputs/composition/amino_acid_composition_per_protein.tsv` — per entry, `master`
  rows: `free_frac_<A..Y>`, `residue_frac_<A..Y>`, `mw`.
- Layer B: `config/mass_fractions/<ft>.ini` — per entry `w_tier1` / `w_tier2` (within-tier, D31)
  and now `w_combined` (D58), each with `_low` / `_high`; and the same values as one table,
  `config/mass_fractions_per_entry.tsv` (D61): one row per entry, per fiber type `v`, `sd`,
  `valid`, `w_<ft>_tier<N>`, `w_<ft>_combined`, each with `_low` / `_high`, match rule, dataset
  row numbers, provenance in the header. `outputs/mass_fractions/weights_per_pool_entry.tsv`
  unchanged. Aggregation reads the one-table form.
- Bounds: `family_bounds.tsv` (D55), `weighted_bounds.tsv` (isoform / processing / PTM).
- Cross-check: `classical_check_carroll_2004.tsv` (MHC : actin per method; absolute shares).

## What Step 4 must produce

1. **The profiles.** For each fiber type (I, IIa, IIx) and each convention (free-amino-acid
   mass, residue mass): the combined standard (D58) and the contractile-only profile, each as
   twenty fractions summing to one, and their per-amino-acid difference. `outputs/standard/`.
2. **Uncertainty, propagated.** Monte Carlo over the per-row `w_low` / `w_high` intervals
   (D45); the family bounds, isoform, processing, and PTM bounds carried as stated bounds per
   amino acid. Output: an interval per amino acid per profile, and the source of the widest
   interval named.
3. **The gel scenario (D54b).** The combined profile under the weights as they are and under
   weights rescaled so that the MHC : actin ratio equals Carroll 2004's, per fiber type; the
   per-amino-acid difference. Reported as a scenario, not a correction; no weight in the
   standard changes.
4. **Fiber mixes.** Decide D46 (I / IIa / IIx vs slow / fast). If per-muscle profiles are
   reported, find a cited source for fiber-type proportions with an IIa / IIx split and per-type
   fiber area (Johnson 1973 is Type I / II by count and is a citation only, D40). `config/fiber_mixes.ini`, cited per row.
5. **The completeness sensitivity.** The combined profile's sensitivity to the top entries of
   `dataset_rows_outside_pool.tsv` by rank (no naming): how much the profile could move if the
   unmapped and ambiguous genes were in the set.
6. **EAA subset tables and plots** per profile and fiber type.
7. `docs/methods.md` §"Aggregation" written from the run records; `docs/decisions.md` appended;
   `docs/pipeline_map.md` extended with the new stage and its outputs.

## Rules to write (A-rules, `docs/conventions.md`)

- **A0 Inputs** — the composition TSV and the Layer B config, both hashed into every output header.
- **A1 Profile** — p_a = Σ_i w_i · f_{i,a} over the entries of the profile's set, per convention;
  renormalised to one after the sum (the per-protein fractions already sum to one, so this is a check).
- **A2 Sets** — combined (every weighted entry) and contractile (tier 1). No other set is named.
- **A3 Uncertainty** — sampling scheme stated; the number of draws stated; the seed stated.
- **A4 Scenario** — a rescaled-weight profile is labelled a scenario in every file name and header.

## Decided before build (Step 4 thread, 2026-09-13)

| Topic | Decision |
|---|---|
| Command and stages | `python run.py standard`: `aggregate` → `uncertainty` → `plots`, nothing folded; outputs in `outputs/standard/`; `matplotlib` added to requirements. |
| Monte Carlo (A3) — **superseded by D63** | ~~Normal truncated at zero~~ → log space. The excerpts showed SD ≥ median for 22 of the type-I top 100 (43 of 100 in IIx). Per entry a log-normal is fitted exactly to the published median and SD; two quantities sampled: between-fiber spread (σ; a random pure fiber, the D45 reading) and median uncertainty (σ/√n; the interval beside the standard). Draws and seed in `config/aggregation_decisions.ini [monte_carlo]`. The D48 shared-row excess and the family / isoform / processing / PTM terms are stated bounds, not sampled. Per-fiber values (PRIDE deposit, Murgia 2017 tables) would upgrade this to a bootstrap of the same two quantities — to be checked, not blocking. |
| Profile formula (A1, D64) | The molar mixture n_a = Σ (w_i/MW_i) count_{i,a}, both conventions from it; the fraction mixture written as a check (A1c) and the difference disclosed. Wide tables in g per 100 g protein, unnormalised. |
| One scale for "widest term" | Every term expressed as the maximum absolute shift from the standard per amino acid (Monte Carlo: the interval's half-width); stated in the header. Provisional — revisit once the numbers are in. |
| MHC : actin sensitivity (D54b, reframed) | Not "rescale to Carroll". The profile's sensitivity to the MHC : actin ratio across the range the three methods measured — gel, iBAQ × MW, Deshmukh intensity share — read from the table the code already wrote. At each ratio, two rescalings (MHC family scaled with actin fixed; actin family scaled with MHC fixed), all weights renormalised; combined and contractile profiles; types I and IIa only (no IIx factor invented). Files `sensitivity_mhc_actin_*`; headers say no method is a reference; Deshmukh's slow / fast pools placed against I / IIa as the existing table does. No absolute-share scenario. |
| D46 (I / IIa / IIx vs slow / fast) | The standard reports the three types as the dataset gives them (B3). The IIa − IIx per-amino-acid difference is computed; whether slow / fast matters is read from that number. |
| Fiber mixes | The spread between the pure-type profiles brackets every mix. Computed first; a cited mix source is sought only if the bracket is material, and then for a named-muscle comparison (Step 5). |
| Completeness sensitivity | A mass share *s* of unknown composition moves any amino acid's fraction by at most *s*. The outside genes' molar share is converted with the pool's mass-weighted mean MW, labelled as the assumption; reported by rank (top 1, 5, 10, all). No candidate entries fetched (protein set closed). |
| EAA subset | FAO 2013 (D62), author-transcribed into `config/aggregation_decisions.ini`; the nine indispensable amino acids individually and under the report's groupings. |
| Versioning | None before release; input hashes in every header (A0) are provenance, not a version. |
| Output units | Fractions summing to one (stored); g/100 g in the wide human-readable tables. |

## Delivery 2 (2026-09-13): the three stages

`python run.py standard` = `aggregate` → `uncertainty` → `plots` → tests. New: `pipeline/aggregate.py`,
`uncertainty.py`, `plots.py`; tests `test_aggregate.py`, `test_uncertainty.py`,
`test_standard_outputs_current.py`; `requirements.txt` gains `numpy`, `matplotlib`;
`[monte_carlo]` in `config/aggregation_decisions.ini`; A-rules in `conventions.md`; D63, D64; command 4
in `pipeline_map.md`; methods §Aggregation with ⟨placeholders⟩; `excerpt` SPEC extended to
`outputs/standard/`. Smoke-run in the sandbox on the top-100 excerpt (weights rescaled) end to end,
currency checks green.

**Run:** `pip install -r requirements.txt` (numpy, matplotlib), then `python run.py standard`. While
`config/aggregation_decisions.ini` still holds `___`, `aggregate` writes everything but
`eaa_subset.tsv`, logs a WARNING, and one test fails naming the file — fill the transcription and
rerun. Then `python run.py excerpt` and upload.

## Delivery 3 (2026-09-13): the stress stage (D65) and plan R6

Anthony: the important question is not the within-sample or between-subject uncertainty but "how MUCH
the standard changes based on things changing" — twenty amino acids summed over thousands of proteins
may barely move even when the order changes. `pipeline/stress.py` runs between `uncertainty` and
`plots`: composition distance among the largest entries; convergence from the top-k; knock-outs (top-k,
each band family); per-entry influence (zeroed, doubled); tier ratio forced; size tilt w × MWᵅ; TPA
weighting v × N_peptides exactly from the digest; random abuse ×/÷ 2, 3, 10. Magnitudes in
`[stress]` of `config/aggregation_decisions.ini`. Outputs `stress_*.tsv`,
`composition_distance_top_entries.tsv`, `stress_summary.ini`, one figure. Plan R6 issued.

## Delivery 4 (2026-09-13): the deliverable, the names, the formula (D66)

- `outputs/standard/_calculated_amino_acid_standard.tsv` — twenty rows, ten columns (contractile,
  builders, total × fiber type I / IIa / IIx, `standard`), percent of amino acid mass, free
  convention, sum 100; residue-convention twin; `amino_acid_g_per_100g_protein_<conv>.tsv`
  replace the `_wide` tables. The `standard` column = the fiber-type mix of the totals from
  `config/fiber_type_mix.ini` (skeleton, `___`); blank and a failing test until a cited source
  is transcribed (next: the search).
- `config/aggregation_decisions.ini` split by content into `fao_2013_indispensable_amino_acids.ini`
  (Anthony's transcription carried over; commas in lists; the `;` that configparser read as a
  comment in `location` replaced), `uncertainty_settings.ini`, `stress_test_settings.ini`.
  **Anthony deletes `aggregation_decisions.ini` by hand.**
- Naming rule D66: contractile / builders, never Tier 1 / 2 in outputs; "fiber" is the cell.
  Sets are `total`, `contractile`, `builders` in every table; the builders set is new (A2).
- `docs/formula.md`: the calculation by hand with a worked example on real masses.
- MHC : actin sensitivity skips a set that holds neither band family (builders).
- Lists in config accept commas or semicolons.

## Explicitly out of scope

Laboratory AAA comparison (Step 5); USDA ingestion, the Match Rate formula, and the delivery
layer (Step 6); any change to the protein set or the weights.

## Deferred / raised (from 3b)

- Momenzadeh 2023: which of Tables S2 / S3 matches the paper's text (paper step).
- Structural titin : MHC anchor (paper step).
- Match Rate delivery layer: proportion × absorption × burn, surplus above proportion counted as surplus, not loss (Step 6).
- `data/uniprot_sequences.ini` → tables with a content-identity test (clean-up after this step).
- Layer A placeholders in `docs/methods.md` (composition step) still to be filled from the composition run records.

## Handoff to Step 5

_(fill in at completion)_
