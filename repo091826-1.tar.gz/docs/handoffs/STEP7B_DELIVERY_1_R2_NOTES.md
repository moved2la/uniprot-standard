# Step 7b — Delivery 1 R2: `file.<n>.name` (F7 amended) — corrected

**Why R2.** Delivery 1 crashed in `write_readme()`: `file_entries()` had grown a sixth field
(`name`) and only one of its two callers was updated. R2 fixes the second caller and adds a test
that runs `main()` end to end on the synthetic tree — manifest, map and README — so a change to
`file_entries()` that misses a caller fails in the tests, not on the workstation.

**Files in this delivery (only these).** Same three as delivery 1, corrected:
- `pipeline/fetch_literature.py` — the README loop unpacks six values.
- `tests/test_fetch_literature.py` — 17 synthetic tests (13 before Step 7b + 4): config-named file
  found whatever the URL says; trailing-slash URL without a name flags with the fix in the message;
  existing sources keep the URL rule; the whole stage runs end to end.
- `docs/conventions.md` — the F7 row (unchanged from delivery 1).

**Not in this delivery.** `config/literature_sources.ini` — yours.

**The two `bryk_2017` flags** are not the crash. They mean the stage did not find a file under the
name it looked for. What it looked for is in the flag text at the end of the log — which the crash
cut off. After R2 the run completes and prints it; compare it with the folder listing of
`data/literature/bryk_2017/` and the `file.<n>.name` lines.
