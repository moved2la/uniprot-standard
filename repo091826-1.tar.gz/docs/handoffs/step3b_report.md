# Step 3b Report — Deriving the Mass Fractions (Layer B)

**Project:** Sequence-Derived Amino Acid Standard for Human Skeletal Muscle
**Repository:** `uniprot-standard`
**Period:** 2026-09-12 to 2026-09-13
**Status of the step:** complete; every stage green; outputs current on `--check`; 80 tests
**Governing rule:** `PROVENANCE.md`

This report is the narrative companion to `docs/methods.md` (§"Mass fraction derivation"),
`docs/decisions.md` (D50–D60), `docs/pipeline_map.md`, and the run records in
`outputs/mass_fractions/` and `logs/`. Every number below is a row or a line in one of those
files. Sections 2–4 feed the paper's Methods and Results; section 5 feeds its Discussion.

---

## 1. What the step had to produce

Layer A gave the composition of every protein in the set, exactly. Layer B had to say how
much of each protein a fiber holds, so that the standard is a weighted sum rather than a
list — and it had to do so from a downloaded, hashed file by a stated formula, with every
weight traceable to a row.

## 2. What was done

### 2.1 Reading the files before writing against them

A literature-inventory stage was added first: it re-hashes every literature file against
the manifest, lists every archive member with its own hash, and records every workbook's
sheets, row and column counts, and header rows. It found that the Moreno-Justicia 2025
file fetched in 3a as "the proteome" was the transcriptome (a UMI-count matrix), which
led to fetching the description of supplementary files and the correct datasets. Nothing
in this step was written against a file whose headers had not been read by code.

### 2.2 The join and the weights

Dataset 1 (Murgia et al. 2021) identifies proteins by gene name only. Rules B0–B5:
hash check; exact-symbol join with summing of duplicate rows (D47) and splitting of
multi-gene cells (D48); iBAQ × MW with the mature-chain molecular weight (D31); the
dataset's own fiber types (D41); `NaN` with no valid values → zero, listed (B4); the
published SD carried per row (D45, D53a). A symbol UniProt resolves to a pool entry joins
it (B1b, D57).

### 2.3 The gel comparison, three ways

Carroll, Carrithers & Trappe 2004 weighed myosin heavy chain and actin per milligram of
total fiber protein in human single fibers. Their four values were transcribed by the author
with page and figure (D50). A gel band contains every heavy chain that co-migrates, so the
band was mapped to pool entries by anchor genes already cited in the repository and expanded
through the shared-peptide families of the digest at a cutoff of two shared peptides (D52).
The comparison is reported as the ratio each method gives and their quotient, without
attribution of the difference to either method (D54); Deshmukh 2021's intensity share was
added as a third measurement, joined by accession.

### 2.4 What the primary dataset said about itself

Two findings came from Dataset 1 alone. First, the myosin heavy chain split by isoform is
not information: fibers selected as pure 2A or 2X by unique peptides still carry half the
type-I value of MYH7 at the gene level. Families are therefore carried as units and the
composition spread across members, times the family's weight, is written as a bound (D55).
Second, the completeness list — quantified genes not in the pool — was headed by MYLPF, a
sarcomeric protein the ontology does not annotate to the myofibril, followed by the
metabolic enzymes, and then the blood and skin proteins one hopes to see there.

### 2.5 The scope change

The ontology's Tier 2 (`sarcoplasm`) had turned out, in Step 1, to be the
sarcoplasmic-reticulum membrane pool. Tier 2 was redefined as the measured remainder —
every quantified gene not in Tier 1, mapped by code to one reviewed human entry, minus
a cited contaminant list (D56, rules M1–M5) — which required the literature fetch to move
to the head of the protein-set command and 3,794 sequences to be fetched and verified.
Two rules were added when that larger set arrived: R5, the alphabet is the twenty coded
amino acids, so six selenoproteins are excluded and their would-be share written (D59);
and R2e, a non-exact Chain position resolves by rule rather than by fifty-four hand
closures (D60). Then the author decided that the primary standard is the measured
muscle-cell proteome — contractile plus support, one denominator — with the contractile-only
profile reported alongside (D58). The reasoning is in plain language in §5.

### 2.6 Everything the code produces, nothing the assistant summarises

Two corrections to method were made in this step and are recorded because they generalise.
When a ranked top-N or a count was reported from a table by the assistant, it was turned
into an output the stage writes: per-tier and combined ranked tables, and a summary file
with a section per tier and fiber type. And every failure, stop, and test report now lands
in one master log per run that is byte-for-byte what appeared on screen.

## 3. What came out

All figures from `outputs/mass_fractions/`, run 2026-09-13T04:35Z.

### 3.1 The set as weighted

| | count |
|---|---|
| Entries weighted | 3,788 (242 contractile, 3,546 support) |
| Dataset genes mapped to a support member | 3,564 of 3,925 (183 already Tier 1; 98 ambiguous; 77 unmapped; 3 contaminants) |
| Pool entries with no dataset row (w = 0) | 55 |
| Dataset genes outside the pool (listed with mapping outcome) | 121 |
| Excluded under R5 (selenocysteine) | 6, together < 0.01 % of the combined standard |
| Non-exact Chain positions resolved under R2e | 54 |

### 3.2 The combined standard (D58)

| | type I | type IIa | type IIx |
|---|---|---|---|
| Contractile share of the whole | 71.7 % | 72.8 % | 71.6 % |
| Support share of the whole | 28.3 % | 27.2 % | 28.4 % |
| Entries with weight > 0 | 3,575 | 3,683 | 3,460 |
| Share of the ten largest | 54.8 % | 52.9 % | 50.3 % |
| Largest entry | titin, 20.1 % | titin, 20.2 % | titin, 20.1 % |

The first support protein in type I is ATP2A2 at rank 11 (1.6 %).

### 3.3 The gel comparison (`classical_check_carroll_2004.tsv`, cutoff 2)

| MHC : actin | type I | type IIa |
|---|---|---|
| Carroll 2004, gel | 1.56 | 2.21 |
| iBAQ × MW, Murgia 2021 | 2.55 | 3.59 |
| intensity share, Deshmukh 2021 | 3.83 (slow) | 3.91 (fast, ~80/20 IIa/IIx) |

Quotients against the gel: 1.64 / 1.63 and 2.46 / 1.77. At cutoff 1 the myosin family
absorbs single-peptide bridges across the full set and the first quotient rises to 3.9.
Absolute shares of the combined standard against the gel's fraction of total protein are
rows of the same file.

### 3.4 Bounds after weighting

Largest weighted isoform bound in Tier 1: 0.0055 (glutamine, titin); processing 0.0002;
PTM mass 0.0014. Family bounds: 0.020 (lysine, titin family) and 0.015 (arginine, myosin
heavy chain family). Glycosylated entries hold 2–3 % of the contractile tier and 17–19 %
of the support tier.

### 3.5 Between-fiber-type ratios

Moreno-Justicia 2025's pseudobulked slow/fast values compared with Murgia 2021's I/IIa for
2,303 pool entries: median absolute log2 disagreement 0.58 (about 1.5×) between two labs,
two instruments, and two fiber-typing methods.

## 4. What the results say that the plan did not anticipate

1. **The measured contractile : support ratio is about 2.5 : 1**, in every fiber type. It is
   above the classical 2 : 1, and the two reasons are in the material and the method, not in
   any exclusion: single dissected fibers carry no connective wrapping and little blood,
   and iBAQ × MW places titin at twice its classical share.
2. **Three methods, three MHC : actin values.** The two mass-spectrometry values sit nearer
   each other than either sits to the gel. The standard does not adjudicate; the aggregation
   step reports how much the profile moves between them.
3. **The isoform split inside a family is not resolved by gene-level data.** Reported as a
   bound rather than fixed, because the family total is what the standard needs.
4. **The ontology under-annotates the sarcomere.** MYLPF, the fast regulatory light chain,
   is not annotated to the myofibril; under D58 it enters through the support tier with its
   measured weight, and no protein was placed by hand.
5. **A larger set exercises rules the small set never reached.** Selenocysteine, uncertain
   chain boundaries, immunoglobulin constant regions, and non-parsable gene symbols each
   produced one rule and one disclosure, never a hand closure.

## 5. What was learned about method

- **Read the file before writing against it.** An inventory stage costs minutes and caught
  a wrong dataset that three prior readings had not.
- **A comparison is not a grade.** Two measurements that disagree are two measurements;
  the repository reports both and their quotient, and the paper discusses them. Any
  sentence of the form "ours is high because theirs says so" was rejected, and the code
  reflects that: no weight is adjusted by a cross-check.
- **A finding in the primary data beats a cross-technology comparison.** The family
  problem was visible in Dataset 1's own values; the bound is computed from the
  repository's own inputs.
- **Disclose what a rule excludes, as a number.** The selenoproteins are 0.01 %; the
  paper says so rather than "negligible".
- **What the assistant reports must be what the code wrote.** Rankings and counts were
  moved into generated files; the master log makes the screen and the record identical.
- **Scope is the author's.** The change from contractile-only to contractile + support
  was proposed, argued in plain language, and decided by the author (D58), not built into.

The plain-language framing that carried the scope decision — the contractile proteins are
the ropes; the support proteins are finished machines floating in the cell's water; the
free amino acids are loose bricks on the table and are in neither tier; the ratio is
protein against protein — is kept for the paper's introduction.

## 6. Carried forward

| Item | To |
|---|---|
| Aggregate the combined and contractile-only profiles per fiber type, both mass conventions; the per-amino-acid difference between them | Step 4 |
| The profile under weights as they are and under weights rescaled to the gel's MHC : actin; per-amino-acid difference (D54b) | Step 4 |
| Propagate `w_low` / `w_high`, family bounds, isoform / processing / PTM bounds | Step 4 |
| I / IIa / IIx versus slow / fast (D46); fiber-mix source with per-type fiber area | Step 4 |
| Momenzadeh 2023: which table matches the paper's text | Paper step |
| Structural titin : MHC anchor from sarcomere stoichiometry | Paper step (Discussion) |
| Delivery layer for Match Rate: proportion × absorption × burn, with surplus above proportion counted as surplus | Step 6 |
| `data/uniprot_sequences.ini` → tables with a content-identity test | Clean-up after Step 4 |
| Layer A placeholders in `docs/methods.md` (composition step) | Fill from `outputs/composition/composition_summary.ini` and `data/pubchem/`, `data/iupac/` source files |

## 7. Files that constitute the step

Hand-written: `config/mass_fraction_decisions.ini`, `config/carroll_classical_fractionation.ini`,
`config/protein_set_decisions.ini` (tier 2 definition), `docs/*.md`, code and synthetic fixtures.

Fetched: `data/literature/` (12 files, SHA-256 pinned), `data/uniprot_sequences.ini` and `data/uniprot_raw/` (3,794 entries), `data/gene-ontology/`.

Generated: `data/tier2_pool.tsv`, `data/tier2_gene_mapping.tsv`, `config/accessions.ini`, `config/segments.ini`,
`config/mass_fractions/{I,IIa,IIx}.ini`, `outputs/digest/*`, `outputs/literature_inventory/*`,
`outputs/mass_fractions/*`, `outputs/excluded_non_standard_alphabet.tsv`, `outputs/chain_positions_resolved.tsv`, `logs/`.
