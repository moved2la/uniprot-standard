# Handoff — Step 7b: Blood — R2, the build

**From:** the Step 7b part-1 thread, 2026-09-18 (R1 was written at the Step 6 close and amended
after 7a; it is superseded by this document)
**To:** the Step 7b build thread
**Plan:** `docs/00_project_plan_R15.md` §5 Step 7b
**Read first:** `PROVENANCE.md`, `docs/run_order.md`, `docs/conventions.md`, `docs/pipeline_map.md`,
`per_category_gameplan_R3.md` (§2a especially), `docs/decisions.md` D95–D105, `docs/step7b_report.md` (part 1)
**Status:** scope, sources and decisions closed; `fetch-literature` green with ten blood sources;
`config/blood/` empty; `outputs/blood/` not yet created; nothing of the build exists

---

## Goal

Build the blood standard through the run order with the muscle-adapted code, and keep the
adaptation list. **The list is the acceptance criterion** (D71): every muscle assumption the build
had to bend, named, with file and line. A clean build with no list means the list was not kept.

## What is settled — do not reopen

| Decision | In one line |
|---|---|
| D95 | plasma + erythrocytes; leucocytes and platelets excluded and bounded (A8); names `plasma`, `erythrocytes` |
| D96 | blood owns plasma proteins; myoglobin stays with muscle |
| D97 | one tier × two subtypes; columns `total_plasma`, `total_erythrocytes`, `standard`; muscle names left as-is and recorded |
| D98 | pool = what each dataset quantified, M1–M5 on the whole set; contaminants per compartment (plasma: keratins + HB*/CA1; erythrocytes: keratins + ALB) |
| D99 | no metabolite pool |
| D100 | the split — below |
| D101 | sources and roles — below |
| D102 | weights as measured; dominant-protein sensitivity, no adjustment |
| D103 | immunoglobulins by constant-region entries; variable domains an A8 bound |
| D104 | `file.<n>.name`; URL is provenance; §2a protocol |
| D105 | abundance kind per source: `mass_share` as-is, `molar` × MW |

## The sources on disk

All under `data/literature/<source_id>/`, hashed; see `config/literature_sources.ini` for the
file names and `data/literature/manifest_map.tsv` for the `blood` column.

| source | role | the table the build reads | weight column and kind |
|---|---|---|---|
| `bryk_2017` | primary, erythrocytes | `pr7b00025_si_002.xlsx`, sheet "Table S3", header rows 2–3, 2,653 rows | columns P–S "Fraction of total protein Donor 1..4" (Whole erythrocyte), percent, sum 100 per donor — `mass_share` |
| `geyer_2016` | primary, plasma | `1-s2.0-S2405471216300722-mmc3.xlsx`, sheet "Supplementary Table S2", 321 quantified rows | "Run #1".."Run #15" LFQ intensity log10 per replicate; the average column is log10 of the mean — `mass_share` after 10^x, share of the summed quantified set |
| `geyer_2016` | completeness | `…-mmc6.xlsx` Table S5, 965 quantified | for the A8 bound on what S2 does not carry |
| `hortin_2008` | cross-check, plasma | `clinchem_2008_108175-2.xls`, sheet "DataBase", 153 rows | "Data Entry" = UniProt accession (147 rows), "Conc., mg/L Mean" — `mass_share` of the summed table; join by accession |
| `gautier_2018` | cross-check, erythrocytes | article PDF only | hemoglobin share of MS signal ≈ 0.7 (Fig. 2A, p. 2650); the correction of Bryk (p. 2655) |
| `rustad_2004` | split | article PDF | Table I p. 274, Protein, plasma: 64–79 g/L |
| `nordin_2004` | split | article PDF | Table V p. 394 (male Hb 134–170 g/L, EVF 0.395–0.500; MCHC 317–357); Table III p. 389 pooled means |
| `icrp_2002` | split volumes; Layer C | on disk since Step 4b | p. 138 §7.3: RBC 2300 ml, plasma 3000 ml; p. 18 Table 2.8: blood 5600 g M / 4100 g F |
| `anderson_2002` | reference only | — | nothing read into the build |

**Identity columns:** Bryk "Protein IDs" (semicolon-joined accessions, first is the leading one)
and "Gene names"; Geyer "Majority Protein IDs" and "Gene Names"; Hortin "Data Entry" and "Gene".
The muscle stage maps gene symbols to reviewed human entries by code (M-rules); Hortin's six Ig
heavy-chain rows have neither and stay out of the join.

## The split (D100), as config

`config/blood/compartment_mix.ini` (the fiber-type-mix analogue; name it for what it holds):

- volumes: RBC 2300 ml, plasma 3000 ml (icrp_2002, p. 138 §7.3), male
- plasma total protein: 71.5 g/L, midpoint of 64–79 (rustad_2004 Table I p. 274, plasma row);
  female values are the same row (both sexes pooled)
- hemoglobin: 152 g/L blood, midpoint of 134–170 (nordin_2004 Table V p. 394, males);
  haematocrit 0.448, midpoint of 0.395–0.500; MCHC 337 g/L (Table V midpoint; Table III mean also 337);
  female: 117–153 g/L, 0.348–0.459
- hemoglobin's share of erythrocyte protein: **not a config number** — it is D102's sensitivity;
  the split is computed and reported at each measured share (0.53, 0.70, 0.95)
- cross-checks, reported not used: ICRP whole-blood protein 18 % of 5600 g; Hortin's summed table 85.7 g/L
- the spread: interval width → the uncertainty input, conversion stated in the header

## The build, in run order

Blood's stages pass `common.category_outputs("blood")["standard"]` (and `["intermediate"]`) as
`base` and write under `outputs/blood/`; `config/blood/` holds its config. Keep
`docs/run_order.md` current as each command gains a blood form.

1. **Excerpts first.** `run.py excerpt` on the four tables above, before any stage code, so the
   column maps in `config/blood/mass_fraction_decisions.ini` are written against what the files
   actually hold.
2. **Protein set** — two pools, `plasma` and `erythrocytes`, each the measured set of its primary
   (M1–M5 on the whole set, no Gene Ontology seed), minus its contaminant rule (D98). Expect the
   first friction here: `protein_set_decisions.ini` assumes a GO-seeded Tier 1 and a remainder Tier 2.
3. **Composition** — reused as-is; the sequence store is shared.
4. **Mass fractions** — per compartment; the D105 kind switch in the column map; weights within
   each compartment under one denominator (D58); Hortin as the ratio-table cross-check for plasma
   (the Carroll pattern), Gautier's share for erythrocytes.
5. **Aggregate** — one tier × two subtypes (D97); the mix from `compartment_mix.ini`. Expect the
   most friction here: `TIER_NAMES`, `PROFILES`, `FIBER_TYPES`, the three `{"contractile": "1",
   "builders": "2"}` dicts, `load_fiber_type_mix()`, header text.
6. **Uncertainty** — Bryk per-donor spread (n = 4); Geyer replicate spread (n = 15, technical, say
   so); the split's interval width.
7. **Stress** — the muscle scenarios by name won't all apply; the D102 sensitivity is the new one:
   dominant protein rescaled to each measured share, every amino acid's movement reported.
8. **The A8 bounds** — leucocytes/platelets; Ig variable domains; what S2 does not carry vs S5.
9. **Layer C row** — `config/tissue_mass_fractions.ini`: blood 5600 g M / 4100 g F (icrp_2002 p. 18).
10. **Docs** — `docs/step7b_report.md` part 2; `docs/decisions.md` from D106; plan R16; the Step 7c
    handoff **with the adaptation list as its body**; `run_order.md`.

## The adaptation list — started

Record file and line as each is met; these are known already.

| # | Muscle assumption | Where | What blood needs |
|---|---|---|---|
| 1 | tiers are named `contractile` / `builders` | `common.TIER_NAMES`; `aggregate.py` `PROFILES`, three tier dicts, header strings | one tier; names from config |
| 2 | subtypes are `I` / `IIa` / `IIx` "fiber types" | `aggregate.py` `FIBER_TYPES`, `GEL_TYPES`, `load_fiber_type_mix()`, `fiber_type_mix.ini` | `plasma` / `erythrocytes`; a subtype-mix loader that reads names |
| 3 | "tier" = same-dataset weighting; "subtype" = cross-dataset mixing | the whole of `aggregate.py` | say so in the manifest (D97) |
| 4 | Tier 1 seeded from Gene Ontology; Tier 2 the measured remainder | `protein_set_decisions.ini`, `enumerate_pool.py` | a pool that is the measured set, no seed |
| 5 | one contaminant list for the category | `protein_set_decisions.ini` `contaminant_source` | per-compartment rule (D98) |
| 6 | the abundance column is iBAQ (× MW) | `mass_fractions.py` B-rules | `mass_share` \| `molar` per source (D105) |
| 7 | the primary dataset has a per-subtype column set (fiber types) | column maps | each subtype is its own dataset |
| 8 | the MHC:actin and band-family sensitivities | `stress_test_settings.ini`, `aggregate.py` A6 | dominant-protein share sensitivity (D102) |
| 9 | header text says "fiber", "muscle", "contractile" | every writer | templating (7c) |
| 10 | `comparison` is Gorissen-only | `comparison.py` | no blood analogue; skip |

## Sequencing with the author

Same as every step: decide, then build. The order above is a proposal; each stage is a delivery
with its notes; a stage that bends a muscle line gets its line in the list before the delivery
ships. Excerpts and the protein-set decisions are the first conversation of the new thread.

## Deferred / raised, carried in

From part 1: the two-piece erythrocyte compartment if D102 moves the profile a lot; the PRIDE
upgrades (PXD002854, PXD009258); Hortin's six accession-less rows; glutathione (D99).
From Step 7a and Step 6: unchanged (see `docs/step7a_report.md`, "Open").

## Delivery and decision numbering

Deliveries continue at 3 (`step7b_delivery3.tar.gz`); a corrected package is re-issued under a
new revision label; one- or two-file fixes ship as loose files; a delivery contains only the
files it changed, never `config/`. Decisions continue from **D106**.

## The rule this thread earned

Gameplan R3 §2a. The assistant finds sources and article URLs and reads what is on disk; the
author records every file URL as the browser shows it, downloads and places files under their
downloaded names, fills the config; the script makes the hashes. No URL from a pattern, no hash
pre-filled, no rename. The same boundary applies to every value: from the file on disk, with its
location, or not at all.
