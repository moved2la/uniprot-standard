# notes

just a list of some notes so I don't forget

## making tight zip file for passing over reviews

```
tree /F /A outputs > outputs_tree.txt
```

tar czf repo091726-3.tar.gz --exclude=.git --exclude='outputs' --exclude='data' --exclude='logs' --exclude='__pycache__' --exclude='.pytest_cache' --exclude='literature' --exclude='.venv' --exclude='/config/mass_fractions/' --exclude='excerpts' --exclude='config' .

```

Leaves out the  bulky things:

data/gene-ontology/go-basic.obo — its URL, version line, and SHA-256 are in data/gene-ontology/source.ini, and the term tables the run produced
data/uniprot_raw/ — the tabulated, verified form is data/uniprot_verification.ini; the raw JSON is for a reviewer's audit.

## next note:
